NetChain[<|"Type" -> "Chain", "Nodes" -> 
   <|"1" -> <|"Type" -> "Graph", "Inputs" -> 
       <|"Input" -> NeuralNetworks`TensorT[{1, 1}, NeuralNetworks`AtomT]|>, 
      "Outputs" -> <|"Output" -> NeuralNetworks`TensorT[{2, 10}, 
          NeuralNetworks`RealT]|>, "Nodes" -> 
       <|"c01" -> <|"Type" -> "Convolution", "Arrays" -> 
           <|"Weights" -> NumericArray[{{{-0.21882785856723785}}, 
              {{0.3695281147956848}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.008177675306797028, 0.22993579506874084}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c11" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.6767634153366089}}, 
              {{0.29241326451301575}}}, "Real32"], "Biases" -> 
             NumericArray[{0.39003559947013855, -0.41458335518836975}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c21" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.31680211424827576}}, 
              {{-1.0563710927963257}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.5526878237724304, -0.6185968518257141}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c31" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.9374189376831055}}, 
              {{1.0646177530288696}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.26330119371414185, 0.17085227370262146}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c41" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.2174367904663086}}, 
              {{0.06854359805583954}}}, "Real32"], "Biases" -> 
             NumericArray[{0.31850892305374146, 0.1403655707836151}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c51" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.7664971351623535}}, 
              {{-0.6213449835777283}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.26558059453964233, 0.27636459469795227}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c61" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.1457114219665527}}, 
              {{2.5933310985565186}}}, "Real32"], "Biases" -> 
             NumericArray[{0.1908869743347168, 0.13060209155082703}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c71" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.9897505044937134}}, 
              {{-0.0012110201641917229}}}, "Real32"], "Biases" -> 
             NumericArray[{0.0647471472620964, -0.00040175532922148705}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c81" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.9675781726837158}}, 
              {{-1.0565272569656372}}}, "Real32"], "Biases" -> 
             NumericArray[{0.169234037399292, -0.12069711834192276}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c91" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.4857495427131653}}, 
              {{-1.6140384674072266}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.03491566702723503, -0.33847764134407043}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c02" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.13398699462413788}, 
              {-1.0279721021652222}}, {{-0.44274213910102844}, 
              {-0.5121575593948364}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.2002696543931961, 0.1477455049753189}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c12" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.9214223027229309}, 
              {0.6690965294837952}}, {{-0.7646104693412781}, 
              {0.17357072234153748}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.35223114490509033, -0.35798460245132446}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c22" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.12684445083141327}, 
              {-1.2796136140823364}}, {{0.4384671151638031}, 
              {0.14657829701900482}}}, "Real32"], "Biases" -> 
             NumericArray[{0.5846210718154907, -0.5315242409706116}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c32" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.8385934829711914}, 
              {0.8953263759613037}}, {{0.41028085350990295}, 
              {-0.9153178930282593}}}, "Real32"], "Biases" -> 
             NumericArray[{0.22472871840000153, -0.044548340141773224}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c42" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.23924054205417633}, 
              {-0.11203338205814362}}, {{-0.013950138352811337}, 
              {-0.8170044422149658}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.27774861454963684, 0.08811648190021515}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c52" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.4804533123970032}, 
              {-0.04998036473989487}}, {{-0.4651748538017273}, 
              {0.7832905054092407}}}, "Real32"], "Biases" -> 
             NumericArray[{0.23644471168518066, 0.2502663731575012}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c62" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.4778083860874176}, 
              {0.03280412778258324}}, {{0.33548009395599365}, 
              {-0.5596179962158203}}}, "Real32"], "Biases" -> 
             NumericArray[{0.046722039580345154, 0.001845304504968226}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c72" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.9128721356391907}, 
              {-0.001380158239044249}}, {{-0.005579755641520023}, 
              {-1.0878154039382935}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.04103842005133629, -0.010583349503576756}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c82" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.26516085863113403}, 
              {0.9768193960189819}}, {{-0.2803330421447754}, 
              {-0.5344510078430176}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.10589098930358887, -0.010016015730798244}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c92" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.26331958174705505}, 
              {0.9029200077056885}}, {{-0.8357381820678711}, 
              {0.2258388102054596}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.32001644372940063, 0.24199023842811584}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c03" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.05708529055118561}, 
              {-0.21590498089790344}}, {{-0.4403378665447235}, 
              {0.13210438191890717}}}, "Real32"], "Biases" -> 
             NumericArray[{0.03114248439669609, 0.21450598537921906}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c13" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.9042118191719055}, 
              {1.1238733530044556}}, {{1.6641759872436523}, 
              {0.6862341165542603}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.30620038509368896, -0.33340340852737427}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c23" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.1637057065963745}, 
              {0.22915059328079224}}, {{0.9360319972038269}, 
              {-1.435775876045227}}}, "Real32"], "Biases" -> 
             NumericArray[{0.0900760143995285, 0.5542742609977722}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c33" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.6256276965141296}, 
              {0.369751513004303}}, {{0.14834977686405182}, 
              {0.17471933364868164}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.19846534729003906, 0.03971495106816292}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c43" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.38298702239990234}, 
              {1.5200365781784058}}, {{-0.45278626680374146}, 
              {0.027975916862487793}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.09979110956192017, 0.3208683729171753}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c53" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.29214566946029663}, 
              {0.21867096424102783}}, {{0.8921581506729126}, 
              {1.0096372365951538}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.1879538595676422, 0.23670551180839539}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c63" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.12413980811834335}, 
              {0.9433806538581848}}, {{1.9735816717147827}, 
              {-0.8604229092597961}}}, "Real32"], "Biases" -> 
             NumericArray[{0.02423393912613392, 0.06168510392308235}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c73" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.25706946849823}, 
              {-0.0015376134542748332}}, {{0.5455983281135559}, 
              {0.005665273871272802}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.03141848370432854, 0.10263078659772873}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c83" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.4704922437667847}, 
              {-0.11462549865245819}}, {{-0.046970341354608536}, 
              {-0.8117561936378479}}}, "Real32"], "Biases" -> 
             NumericArray[{0.0980776771903038, 0.088446244597435}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c93" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.5758128762245178}, 
              {-0.08823781460523605}}, {{1.1804043054580688}, 
              {-0.28936275839805603}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.2285645604133606, -0.2863333821296692}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c04" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.007023787125945091}, 
              {0.472401887178421}}, {{-0.008556478656828403}, 
              {-0.5028349757194519}}}, "Real32"], "Biases" -> 
             NumericArray[{0.1923956274986267, -0.29425859451293945}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c14" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.6056365370750427}, 
              {-0.7342392206192017}}, {{0.17395451664924622}, 
              {0.9169048070907593}}}, "Real32"], "Biases" -> 
             NumericArray[{0.27468734979629517, -0.3221864700317383}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c24" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.5172627568244934}, 
              {-0.23020164668560028}}, {{0.14711134135723114}, 
              {-1.2834148406982422}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.38735586404800415, -0.539411187171936}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c34" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.19814372062683105}, 
              {0.02222730778157711}}, {{1.4471993446350098}, 
              {-0.24814380705356598}}}, "Real32"], "Biases" -> 
             NumericArray[{0.036529842764139175, -0.1304677575826645}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c44" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.2102175951004028}, 
              {-0.6127427816390991}}, {{-1.1053690910339355}, 
              {0.7759988903999329}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.34454038739204407, 0.36226120591163635}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c54" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.49725764989852905}, 
              {0.26143211126327515}}, {{0.552888035774231}, 
              {-1.9394723176956177}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.02211489900946617, -0.25853681564331055}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c64" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.22671198844909668}, 
              {-0.014952722005546093}}, {{-0.627901554107666}, 
              {-0.0426727756857872}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.028475675731897354, -0.01759270578622818}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c74" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.4312670230865479}, 
              {-0.5035866498947144}}, {{-1.0333093404769897}, 
              {0.9007336497306824}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.025280678644776344, 0.09278026968240738}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c84" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.541711449623108}, 
              {-0.17790579795837402}}, {{0.6466315984725952}, 
              {-0.17452369630336761}}}, "Real32"], "Biases" -> 
             NumericArray[{0.17269651591777802, -0.278643935918808}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c94" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.03746843338012695}, 
              {0.4314681887626648}}, {{-0.24412083625793457}, 
              {0.12118920683860779}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.26456382870674133, -0.05522013083100319}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c05" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.5539489388465881}, 
              {0.799781084060669}}, {{0.16775260865688324}, 
              {-0.40205857157707214}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.2876588702201843, -0.10313306748867035}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c15" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.2059024572372437}, 
              {1.156015396118164}}, {{-0.2330208420753479}, 
              {-0.24736781418323517}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.3039278984069824, -0.14904841780662537}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c25" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.05757402256131172}, 
              {-0.265456885099411}}, {{1.085472583770752}, 
              {2.5173909664154053}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.07548070698976517, -0.5227234959602356}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c35" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.48295846581459045}, 
              {0.4982956051826477}}, {{0.12453575432300568}, 
              {-0.632755696773529}}}, "Real32"], "Biases" -> 
             NumericArray[{0.06997040659189224, 0.07159023731946945}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c45" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.8850038647651672}, 
              {-0.9833138585090637}}, {{0.9190841913223267}, 
              {-1.0209604501724243}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.5902135968208313, -0.2562784254550934}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c55" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.13076187670230865}, 
              {-0.667717456817627}}, {{-0.16708523035049438}, 
              {1.5424940586090088}}}, "Real32"], "Biases" -> 
             NumericArray[{0.058767836540937424, -0.2231031358242035}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c65" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.5094112157821655}, 
              {-0.02981080859899521}}, {{0.005798738915473223}, 
              {0.29505735635757446}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.11506067216396332, -0.11269085854291916}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c75" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.0732152909040451}, 
              {-0.1370888352394104}}, {{-0.9998384118080139}, 
              {-0.3948153853416443}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.27206265926361084, 0.11018894612789154}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c85" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.6824917793273926}, 
              {0.12873771786689758}}, {{0.30465152859687805}, 
              {0.8286644816398621}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.23820100724697113, -0.24277783930301666}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c95" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.4859125018119812}, 
              {-0.06137705594301224}}, {{0.10307943820953369}, 
              {0.0015318748774006963}}}, "Real32"], "Biases" -> 
             NumericArray[{0.17516687512397766, -0.23202790319919586}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "output" -> <|"Type" -> "Catenate", 
          "Arrays" -> <||>, "Parameters" -> <|"Level" -> 2|>, 
          "Inputs" -> <|"Input1" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT], "Input2" -> NeuralNetworks`TensorT[
              {2, 1}, NeuralNetworks`RealT], "Input3" -> 
             NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input4" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input5" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input6" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input7" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input8" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input9" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input10" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 10}, 
              NeuralNetworks`RealT]|>|>|>, "Edges" -> 
       {NeuralNetworks`NetPath["Nodes", "c01", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c11", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c21", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c31", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c41", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c51", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c61", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c71", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c81", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c91", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c02", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c01", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c12", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c11", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c22", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c21", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c32", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c31", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c42", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c41", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c52", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c51", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c62", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c61", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c72", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c71", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c82", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c81", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c92", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c91", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c03", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c02", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c13", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c12", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c23", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c22", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c33", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c32", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c43", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c42", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c53", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c52", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c63", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c62", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c73", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c72", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c83", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c82", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c93", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c92", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c04", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c03", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c14", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c13", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c24", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c23", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c34", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c33", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c44", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c43", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c54", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c53", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c64", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c63", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c74", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c73", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c84", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c83", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c94", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c93", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c05", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c04", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c15", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c14", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c25", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c24", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c35", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c34", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c45", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c44", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c55", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c54", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c65", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c64", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c75", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c74", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c85", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c84", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c95", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c94", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input1"] -> 
         NeuralNetworks`NetPath["Nodes", "c05", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input2"] -> 
         NeuralNetworks`NetPath["Nodes", "c15", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input3"] -> 
         NeuralNetworks`NetPath["Nodes", "c25", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input4"] -> 
         NeuralNetworks`NetPath["Nodes", "c35", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input5"] -> 
         NeuralNetworks`NetPath["Nodes", "c45", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input6"] -> 
         NeuralNetworks`NetPath["Nodes", "c55", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input7"] -> 
         NeuralNetworks`NetPath["Nodes", "c65", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input8"] -> 
         NeuralNetworks`NetPath["Nodes", "c75", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input9"] -> 
         NeuralNetworks`NetPath["Nodes", "c85", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input10"] -> 
         NeuralNetworks`NetPath["Nodes", "c95", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Outputs", "Output"] -> NeuralNetworks`NetPath[
          "Nodes", "output", "Outputs", "Output"]}|>, 
    "2" -> <|"Type" -> "Pooling", "Arrays" -> <||>, 
      "Parameters" -> <|"KernelSize" -> {2}, "Stride" -> {1}, 
        "PaddingSize" -> {{0, 0}}, "Function" -> Max, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$Channels" -> 2, "$InputSize" -> {10}, 
        "$OutputSize" -> {9}, "$MXPoolingConvention" -> "valid", 
        "$MXGlobalPool" -> False, "$IgnorePadding" -> False, 
        "$InputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT], 
        "$OutputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT]|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 10}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "3" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.24085800349712372}, 
          {0.4946979880332947}}, {{1.0830718278884888}, 
          {1.217444658279419}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.06695523858070374, -0.2327110469341278}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "4" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.1577339619398117}, 
          {0.03247549384832382}}, {{-0.09477035701274872}, 
          {-1.2518348693847656}}}, "Real32"], "Biases" -> 
         NumericArray[{0.12339425832033157, 0.19662737846374512}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "5" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.6999468803405762}, 
          {-1.1810778379440308}}, {{-0.024371305480599403}, 
          {-0.6266084909439087}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.1679554581642151, -0.21022158861160278}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "6" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.5149964094161987}, 
          {0.6693060398101807}}, {{0.5470666885375977}, 
          {-0.6916273236274719}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.14675085246562958, -0.08087735623121262}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "7" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.441863089799881}, 
          {2.1480307579040527}}, {{-0.912574291229248}, 
          {0.05175058916211128}}}, "Real32"], "Biases" -> 
         NumericArray[{0.0005556890391744673, 0.11784925311803818}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "8" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.5412590503692627}, 
          {0.49059075117111206}}, {{-0.49088799953460693}, 
          {0.34572041034698486}}}, "Real32"], "Biases" -> 
         NumericArray[{0.08705728501081467, 0.0825543999671936}, "Real32"]|>, 
      "Parameters" -> <|"OutputChannels" -> 2, "KernelSize" -> {1}, 
        "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, "Dilation" -> {1}, 
        "ChannelGroups" -> 1, "Dimensionality" -> 1, "Interleaving" -> False, 
        "$InputChannels" -> 2, "$InputSize" -> {9}, "$OutputSize" -> {9}, 
        "$WeightsInputChannels" -> 2|>, "Inputs" -> 
       <|"Input" -> NeuralNetworks`TensorT[{2, 9}, NeuralNetworks`RealT]|>, 
      "Outputs" -> <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "9" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.17494221031665802}, 
          {0.2575373351573944}}, {{-0.8349917531013489}, 
          {-0.9517839550971985}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.004439208190888166, -0.0757230892777443}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "10" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.003888730425387621}, 
          {0.49963581562042236}}, {{-0.002551660407334566}, 
          {-1.3075870275497437}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.04702968895435333, 0.06801029294729233}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "11" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.5783841013908386}, 
          {-0.9116961359977722}}, {{0.7719004154205322}, 
          {0.36317601799964905}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.07923145592212677, 0.04594423994421959}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "12" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.38258999586105347}, 
          {-0.3720493018627167}}, {{-0.16914410889148712}, 
          {0.871988832950592}}}, "Real32"], "Biases" -> 
         NumericArray[{0.07426177710294724, 0.08014101535081863}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "13" -> <|"Type" -> "Pooling", 
      "Arrays" -> <||>, "Parameters" -> <|"KernelSize" -> {2}, 
        "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, "Function" -> Max, 
        "Dimensionality" -> 1, "Interleaving" -> False, "$Channels" -> 2, 
        "$InputSize" -> {9}, "$OutputSize" -> {8}, "$MXPoolingConvention" -> 
         "valid", "$MXGlobalPool" -> False, "$IgnorePadding" -> False, 
        "$InputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT], 
        "$OutputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT]|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 8}, 
          NeuralNetworks`RealT]|>|>, "14" -> <|"Type" -> "Flatten", 
      "Arrays" -> <||>, "Parameters" -> <|"Level" -> Infinity|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 8}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{16}, NeuralNetworks`RealT]|>|>, 
    "15" -> <|"Type" -> "Linear", "Arrays" -> 
       <|"Weights" -> NumericArray[{{0.35281944274902344, 0.4583169221878052, 
          -0.22008126974105835, 0.09915788471698761, 0.2881051301956177, 
          0.09413086622953415, 0.17473851144313812, -0.12165994197130203, 
          -0.32895785570144653, -0.26772937178611755, -0.5344775319099426, 
          -0.09561459720134735, -0.050995197147130966, -0.5251652598381042, 
          -0.3225032687187195, 0.20616701245307922}, {-0.12257827073335648, 
          0.12779501080513, -0.44636061787605286, 0.11791133880615234, 
          0.0034729554317891598, 0.07696408033370972, -0.08410926908254623, 
          0.09693069010972977, 0.09678806364536285, -0.4008062481880188, 
          0.3378949761390686, 0.13972730934619904, -0.05061837658286095, 
          -0.5959383249282837, 0.05711541697382927, -0.1147431805729866}, 
          {-0.41086065769195557, -0.768943727016449, -0.3928602933883667, 
          -0.1429624706506729, -0.10915940254926682, 0.08441676199436188, 
          -0.310745507478714, -0.4896974563598633, -0.4774862825870514, 
          -0.3433762192726135, 0.16455458104610443, -0.33122870326042175, 
          -0.4570524990558624, 0.5006064176559448, -0.34727421402931213, 
          -0.21481482684612274}, {0.11743798106908798, -0.5934690833091736, 
          0.20376966893672943, -0.5289614200592041, -0.023796478286385536, 
          0.27376651763916016, -0.3237719237804413, -0.024672551080584526, 
          0.016807736828923225, 0.2827956974506378, 0.25286146998405457, 
          0.6495653986930847, -0.11116434633731842, 0.12280040979385376, 
          0.03137762099504471, 0.19853399693965912}, {0.07764673978090286, 
          -0.14272654056549072, -0.2779717743396759, 0.013649321161210537, 
          -0.3341110646724701, 0.23763211071491241, 0.10287357121706009, 
          0.036720361560583115, 0.03847179934382439, 0.16131353378295898, 
          0.28344035148620605, 0.03517235442996025, 0.3435002863407135, 
          -0.35270389914512634, -0.48124125599861145, 0.16505469381809235}, 
          {-0.0976720005273819, 0.07794015109539032, -0.3926597833633423, 
          0.2529676854610443, -0.0016770639922469854, 0.07224177569150925, 
          -0.5086023211479187, 0.1777118444442749, -0.2552422881126404, 
          0.017167987301945686, 0.18272913992404938, 0.18926669657230377, 
          0.20739535987377167, -0.08077044039964676, 0.14173032343387604, 
          -0.0864839181303978}}, "Real32"], "Biases" -> 
         NumericArray[{-0.03712688386440277, 0.06600462645292282, 
          -0.1456986516714096, -0.05172034353017807, 0.04356718808412552, 
          0.12712498009204865}, "Real32"]|>, "Parameters" -> 
       <|"OutputDimensions" -> {6}, "$OutputSize" -> 6, "$InputSize" -> 16, 
        "$InputDimensions" -> {16}|>, "Inputs" -> 
       <|"Input" -> NeuralNetworks`TensorT[{16}, NeuralNetworks`RealT]|>, 
      "Outputs" -> <|"Output" -> NeuralNetworks`TensorT[{6}, 
          NeuralNetworks`RealT]|>|>, "16" -> <|"Type" -> "Linear", 
      "Arrays" -> <|"Weights" -> NumericArray[{{0.37207359075546265, 
          -0.03311562538146973, -0.3032832145690918, -0.030838409438729286, 
          -0.15248732268810272, -0.01727215386927128}, {-0.3276711106300354, 
          -0.903780460357666, 0.18030232191085815, 0.33683401346206665, 
          0.0512886643409729, 0.05571962893009186}, {0.4049108922481537, 
          -0.6544215083122253, 0.06829007714986801, 0.30012887716293335, 
          -0.23052392899990082, 0.004340612795203924}, {0.20630525052547455, 
          -0.5144193768501282, 0.6392261981964111, 0.14498475193977356, 
          -0.1364881694316864, 0.0009491610107943416}}, "Real32"], 
        "Biases" -> NumericArray[{0.1616557240486145, 0.1820491999387741, 
          0.011249618604779243, -0.16636843979358673}, "Real32"]|>, 
      "Parameters" -> <|"OutputDimensions" -> {4}, "$OutputSize" -> 4, 
        "$InputSize" -> 6, "$InputDimensions" -> {6}|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{6}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{4}, NeuralNetworks`RealT]|>|>, 
    "17" -> <|"Type" -> "Linear", "Arrays" -> 
       <|"Weights" -> NumericArray[{{0.5539978742599487, 0.2634052634239197, 
          0.0029963075648993254, -0.5109025835990906}, {0.03921377658843994, 
          -0.24871571362018585, 0.13413941860198975, 0.06817203015089035}}, 
          "Real32"], "Biases" -> NumericArray[{0.18628495931625366, 
          0.027399402111768723}, "Real32"]|>, "Parameters" -> 
       <|"OutputDimensions" -> {2}, "$OutputSize" -> 2, "$InputSize" -> 4, 
        "$InputDimensions" -> {4}|>, "Inputs" -> 
       <|"Input" -> NeuralNetworks`TensorT[{4}, NeuralNetworks`RealT]|>, 
      "Outputs" -> <|"Output" -> NeuralNetworks`TensorT[{2}, 
          NeuralNetworks`RealT]|>|>, "18" -> <|"Type" -> "Linear", 
      "Arrays" -> <|"Weights" -> NumericArray[{{0.0222132820636034, 
          -0.06264743208885193}, {-0.8528780341148376, -0.0677356868982315}}, 
          "Real32"], "Biases" -> NumericArray[{0.21558402478694916, 
          -0.21559295058250427}, "Real32"]|>, "Parameters" -> 
       <|"OutputDimensions" -> {2}, "$OutputSize" -> 2, "$InputSize" -> 2, 
        "$InputDimensions" -> {2}|>, "Inputs" -> 
       <|"Input" -> NeuralNetworks`TensorT[{2}, NeuralNetworks`RealT]|>, 
      "Outputs" -> <|"Output" -> NeuralNetworks`TensorT[{2}, 
          NeuralNetworks`RealT]|>|>, "19" -> <|"Type" -> "Softmax", 
      "Arrays" -> <||>, "Parameters" -> <|"Level" -> -1|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2}, NeuralNetworks`RealT]|>|>|>, 
  "Edges" -> {NeuralNetworks`NetPath["Nodes", "1", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Inputs", "Input"], 
    NeuralNetworks`NetPath["Nodes", "2", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "1", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "3", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "2", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "4", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "3", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "5", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "4", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "6", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "5", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "7", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "6", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "8", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "7", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "9", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "8", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "10", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "9", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "11", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "10", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "12", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "11", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "13", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "12", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "14", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "13", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "15", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "14", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "16", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "15", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "17", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "16", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "18", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "17", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "19", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "18", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Outputs", "Output"] -> NeuralNetworks`NetPath[
      "Nodes", "19", "Outputs", "Output"]}, 
  "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
      NeuralNetworks`AtomT]|>, "Outputs" -> 
   <|"Output" -> NetDecoder["Class", <|"Labels" -> {"False", "True"}, 
       "InputDepth" -> 1, "Multilabel" -> False, "Dimensions" -> 2, 
       "$Rank" -> 0, "$Version" -> "13.0.3"|>, NeuralNetworks`TensorT[{2}, 
       NeuralNetworks`RealT]]|>|>, <|"Version" -> "13.0.3", 
  "Unstable" -> False|>]
