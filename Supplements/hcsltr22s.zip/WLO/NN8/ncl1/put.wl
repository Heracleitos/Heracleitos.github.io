NetChain[<|"Type" -> "Chain", "Nodes" -> 
   <|"1" -> <|"Type" -> "Graph", "Inputs" -> 
       <|"Input" -> NeuralNetworks`TensorT[{1, 1}, NeuralNetworks`AtomT]|>, 
      "Outputs" -> <|"Output" -> NeuralNetworks`TensorT[{2, 10}, 
          NeuralNetworks`RealT]|>, "Nodes" -> 
       <|"c01" -> <|"Type" -> "Convolution", "Arrays" -> 
           <|"Weights" -> NumericArray[{{{2.0680201995304515*^-10}}, 
              {{-2.2781145572662354}}}, "Real32"], "Biases" -> 
             NumericArray[{-3.757680555604992*^-10, -0.5012540221214294}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c11" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.0043868706561625}}, 
              {{-0.9031257033348083}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.014614487998187542, 0.08073917776346207}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c21" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.006701298989355564}}, 
              {{-0.7132200598716736}}}, "Real32"], "Biases" -> 
             NumericArray[{0.018383679911494255, 0.5334494709968567}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c31" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.3567768335342407}}, 
              {{-1.8280435800552368}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.37582990527153015, -0.3799625635147095}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c41" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.2506890296936035}}, 
              {{0.6252235770225525}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.06285393983125687, 0.09824755042791367}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c51" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.9558050632476807}}, 
              {{-2.3724663257598877}}}, "Real32"], "Biases" -> 
             NumericArray[{0.5947205424308777, 0.5027756094932556}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c61" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.8386726975440979}}, 
              {{-0.00006582459900528193}}}, "Real32"], "Biases" -> 
             NumericArray[{0.4173085689544678, -0.0007924182573333383}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c71" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.6353832483291626}}, 
              {{-0.3927020728588104}}}, "Real32"], "Biases" -> 
             NumericArray[{0.6859716773033142, -0.6387617588043213}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c81" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.288923442363739}}, 
              {{0.8101769685745239}}}, "Real32"], "Biases" -> 
             NumericArray[{0.3653709888458252, -0.4032607674598694}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c91" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.337359219789505}}, 
              {{0.0001800633908715099}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.28662988543510437, 0.0007138745277188718}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c02" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[
              {{{-7.438812898996616*^-10}, {-0.7573838829994202}}, 
              {{6.487536619026457*^-10}, {0.5945327877998352}}}, "Real32"], 
            "Biases" -> NumericArray[{0.2889840602874756, 
              -0.40008196234703064}, "Real32"]|>, "Parameters" -> 
           <|"OutputChannels" -> 2, "KernelSize" -> {1}, "Stride" -> {1}, 
            "PaddingSize" -> {{0, 0}}, "Dilation" -> {1}, "ChannelGroups" -> 
             1, "Dimensionality" -> 1, "Interleaving" -> False, 
            "$InputChannels" -> 2, "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c12" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.00490421149879694}, 
              {-1.1879677772521973}}, {{-0.01910710521042347}, 
              {0.002830265322700143}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.08161520957946777, 0.004831863567233086}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c22" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.0001283304300159216}, 
              {-1.5500375032424927}}, {{0.05854246765375137}, 
              {0.006149604916572571}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.49005478620529175, 0.00690041296184063}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c32" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.07658366113901138}, 
              {1.809989094734192}}, {{0.6997376680374146}, 
              {0.7610708475112915}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.3298143148422241, -0.3052978515625}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c42" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.9078119397163391}, 
              {0.3908769488334656}}, {{-0.21363498270511627}, 
              {0.09226425737142563}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.0200798436999321, -0.020491212606430054}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c52" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.16829147934913635}, 
              {-0.411083847284317}}, {{0.7695849537849426}, 
              {1.2460541725158691}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.3727132976055145, 0.4329526126384735}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c62" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.2734947204589844}, 
              {0.00033940732828341424}}, {{-0.0008153236703947186}, 
              {0.4949362277984619}}}, "Real32"], "Biases" -> 
             NumericArray[{0.3827076554298401, -0.004867549054324627}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c72" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.8430476188659668}, 
              {-0.3396514356136322}}, {{0.054797086864709854}, 
              {1.782538652420044}}}, "Real32"], "Biases" -> 
             NumericArray[{0.5493755340576172, -0.527993381023407}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c82" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.7692626714706421}, 
              {0.5263959169387817}}, {{0.7700137495994568}, 
              {0.7740230560302734}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.28304508328437805, -0.3522438108921051}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c92" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.023088308051228523}, 
              {0.7642809152603149}}, {{-1.4170045852661133}, 
              {0.00004356199860922061}}}, "Real32"], "Biases" -> 
             NumericArray[{0.0018889070488512516, 0.3571798503398895}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c03" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.3418964147567749}, 
              {1.108473777770996}}, {{-0.8720109462738037}, 
              {1.2191948890686035}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.13184766471385956, -0.4084106683731079}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c13" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.005672024097293615}, 
              {-0.0021949862129986286}}, {{0.9959623217582703}, 
              {-0.002955845557153225}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.011009860783815384, -0.09121605008840561}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c23" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.404522180557251}, 
              {-0.3946375846862793}}, {{-1.2723546028137207}, 
              {-0.756313145160675}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.4196115732192993, 0.5083643794059753}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c33" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.09229051321744919}, 
              {1.0215504169464111}}, {{1.1031949520111084}, 
              {1.9123082160949707}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.0730559378862381, -0.29978975653648376}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c43" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.6172125935554504}, 
              {-0.058313511312007904}}, {{-1.0876314640045166}, 
              {-0.09842642396688461}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.5918667912483215, 0.4363870322704315}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c53" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.24966667592525482}, 
              {-0.19929315149784088}}, {{1.0586202144622803}, 
              {-0.5732746720314026}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.1413881927728653, -0.3706815540790558}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c63" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.17166991531848907}, 
              {-0.888370156288147}}, {{-1.1994189023971558}, 
              {0.5417835712432861}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.3267099857330322, -0.3428195118904114}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c73" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.2629629373550415}, 
              {-0.1984042525291443}}, {{-0.8818804621696472}, 
              {0.29941269755363464}}}, "Real32"], "Biases" -> 
             NumericArray[{0.41774335503578186, -0.5453571677207947}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c83" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.3131573498249054}, 
              {0.5003740787506104}}, {{-0.4671063721179962}, 
              {-0.31052517890930176}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.0496927946805954, 0.2177352011203766}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c93" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.137831687927246}, 
              {0.07788191735744476}}, {{-0.7389550805091858}, 
              {-0.8089329600334167}}}, "Real32"], "Biases" -> 
             NumericArray[{0.3408079743385315, -0.5017907023429871}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c04" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.3002181947231293}, 
              {0.6078387498855591}}, {{-0.8915069699287415}, 
              {0.08912578225135803}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.4706859886646271, -0.026880456134676933}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c14" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.3679516613483429}, 
              {-1.11640202999115}}, {{0.513304591178894}, 
              {0.2348712980747223}}}, "Real32"], "Biases" -> 
             NumericArray[{0.11335938423871994, -0.08978859335184097}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c24" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.41618961095809937}, 
              {0.4596746265888214}}, {{1.6235249042510986}, 
              {-0.845213770866394}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.0571930967271328, -0.3837467133998871}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c34" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.7669590711593628}, 
              {-0.901923656463623}}, {{1.1546398401260376}, 
              {0.14303936064243317}}}, "Real32"], "Biases" -> 
             NumericArray[{0.23869366943836212, -0.17157422006130219}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c44" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.2933705151081085}, 
              {0.2343708574771881}}, {{0.5066260695457458}, 
              {-0.25765717029571533}}}, "Real32"], "Biases" -> 
             NumericArray[{0.6774389147758484, -0.6765433549880981}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c54" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.9258397817611694}, 
              {1.6686508655548096}}, {{1.793856143951416}, 
              {-0.6136748790740967}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.27244144678115845, 0.3004501760005951}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c64" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.1221694946289062}, 
              {1.8280714750289917}}, {{0.41846728324890137}, 
              {-0.07256100326776505}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.32726702094078064, 0.0974157303571701}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c74" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.5129863023757935}, 
              {-0.45929497480392456}}, {{-0.8849146366119385}, 
              {1.5241745710372925}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.31554079055786133, -0.5573580265045166}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c84" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.0077758170664310455}, 
              {-0.9845835566520691}}, {{-0.006488383747637272}, 
              {-0.1306341141462326}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.1854994297027588, -0.034471530467271805}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c94" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.658247947692871}, 
              {0.5922218561172485}}, {{0.9404099583625793}, 
              {1.0698336362838745}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.4680129587650299, -0.5748136639595032}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c05" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.1532458066940308}, 
              {-0.3816564977169037}}, {{-0.5876904726028442}, 
              {-0.013685224577784538}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.7918396592140198, 0.24243609607219696}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c15" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.3101661801338196}, 
              {-0.1454664170742035}}, {{1.0873768329620361}, 
              {-0.8186943531036377}}}, "Real32"], "Biases" -> 
             NumericArray[{0.45163536071777344, -0.07929226756095886}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c25" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.0009925452759489417}, 
              {0.11750204861164093}}, {{0.0007542567909695208}, 
              {1.5202513933181763}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.5621784925460815, -0.2954516112804413}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c35" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.49326616525650024}, 
              {-0.5943271517753601}}, {{-0.41935238242149353}, 
              {0.3518426716327667}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.03594177961349487, -0.13690386712551117}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c45" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.0303994417190552}, 
              {1.333370566368103}}, {{-0.5144848823547363}, 
              {1.7945531606674194}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.7199323177337646, -0.613399088382721}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c55" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.4342667758464813}, 
              {0.1318080723285675}}, {{0.5923553109169006}, 
              {-0.24392326176166534}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.3380934000015259, -0.486773818731308}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c65" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.3040353059768677}, 
              {-0.05522683262825012}}, {{-0.9950430989265442}, 
              {0.016722584143280983}}}, "Real32"], "Biases" -> 
             NumericArray[{0.5486757159233093, 0.39339396357536316}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c75" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.5263607501983643}, 
              {1.6187664270401}}, {{0.5721684098243713}, 
              {0.02400548942387104}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.49236413836479187, -0.6516178846359253}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c85" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.8021529912948608}, 
              {0.7177242636680603}}, {{-0.1587931364774704}, 
              {0.16442199051380157}}}, "Real32"], "Biases" -> 
             NumericArray[{0.03369273245334625, 0.4118298888206482}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c95" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.7220228910446167}, 
              {-0.562291145324707}}, {{-0.08709791302680969}, 
              {1.0051029920578003}}}, "Real32"], "Biases" -> 
             NumericArray[{0.6814839839935303, -0.33984094858169556}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "output" -> <|"Type" -> "Catenate", 
          "Arrays" -> <||>, "Parameters" -> <|"Level" -> 2|>, 
          "Inputs" -> <|"Input1" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT], "Input2" -> NeuralNetworks`TensorT[
              {2, 1}, NeuralNetworks`RealT], "Input3" -> 
             NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input4" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input5" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input6" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input7" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input8" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input9" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input10" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 10}, 
              NeuralNetworks`RealT]|>|>|>, "Edges" -> 
       {NeuralNetworks`NetPath["Nodes", "c01", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c11", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c21", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c31", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c41", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c51", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c61", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c71", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c81", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c91", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c02", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c01", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c12", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c11", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c22", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c21", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c32", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c31", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c42", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c41", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c52", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c51", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c62", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c61", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c72", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c71", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c82", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c81", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c92", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c91", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c03", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c02", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c13", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c12", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c23", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c22", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c33", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c32", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c43", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c42", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c53", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c52", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c63", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c62", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c73", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c72", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c83", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c82", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c93", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c92", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c04", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c03", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c14", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c13", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c24", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c23", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c34", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c33", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c44", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c43", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c54", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c53", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c64", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c63", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c74", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c73", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c84", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c83", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c94", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c93", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c05", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c04", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c15", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c14", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c25", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c24", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c35", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c34", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c45", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c44", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c55", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c54", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c65", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c64", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c75", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c74", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c85", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c84", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c95", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c94", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input1"] -> 
         NeuralNetworks`NetPath["Nodes", "c05", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input2"] -> 
         NeuralNetworks`NetPath["Nodes", "c15", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input3"] -> 
         NeuralNetworks`NetPath["Nodes", "c25", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input4"] -> 
         NeuralNetworks`NetPath["Nodes", "c35", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input5"] -> 
         NeuralNetworks`NetPath["Nodes", "c45", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input6"] -> 
         NeuralNetworks`NetPath["Nodes", "c55", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input7"] -> 
         NeuralNetworks`NetPath["Nodes", "c65", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input8"] -> 
         NeuralNetworks`NetPath["Nodes", "c75", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input9"] -> 
         NeuralNetworks`NetPath["Nodes", "c85", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input10"] -> 
         NeuralNetworks`NetPath["Nodes", "c95", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Outputs", "Output"] -> NeuralNetworks`NetPath[
          "Nodes", "output", "Outputs", "Output"]}|>, 
    "2" -> <|"Type" -> "Pooling", "Arrays" -> <||>, 
      "Parameters" -> <|"KernelSize" -> {2}, "Stride" -> {1}, 
        "PaddingSize" -> {{0, 0}}, "Function" -> Max, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$Channels" -> 2, "$InputSize" -> {10}, 
        "$OutputSize" -> {9}, "$MXPoolingConvention" -> "valid", 
        "$MXGlobalPool" -> False, "$IgnorePadding" -> False, 
        "$InputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT], 
        "$OutputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT]|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 10}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "3" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.36501720547676086}, 
          {0.5425106883049011}}, {{-0.00045285484520718455}, 
          {-0.0003015869006048888}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.24525058269500732, 0.009301748126745224}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "4" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.9815096259117126}, 
          {-0.0006163225043565035}}, {{-0.006555979605764151}, 
          {0.017858345061540604}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.19620755314826965, 0.0033679332118481398}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "5" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-1.8782185316085815}, 
          {0.2287263125181198}}, {{-0.6088605523109436}, 
          {-0.6164761781692505}}}, "Real32"], "Biases" -> 
         NumericArray[{0.17693714797496796, 0.19196075201034546}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "6" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.33473730087280273}, 
          {-1.0272939205169678}}, {{-1.2743704319000244}, 
          {-0.25178661942481995}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.17543549835681915, -0.16094304621219635}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "7" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.047306038439273834}, 
          {0.02282252348959446}}, {{-0.20697680115699768}, 
          {-0.8480802178382874}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.011790783144533634, 0.14911532402038574}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "8" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.0003100885369349271}, 
          {1.1640013456344604}}, {{0.45250821113586426}, 
          {-0.0003085461212322116}}}, "Real32"], "Biases" -> 
         NumericArray[{0.1408853828907013, -0.0011963591678068042}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "9" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{1.6706887483596802}, 
          {0.16744984686374664}}, {{-0.7808162569999695}, 
          {0.13034458458423615}}}, "Real32"], "Biases" -> 
         NumericArray[{0.1400865614414215, -0.13486698269844055}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "10" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.17847906053066254}, 
          {0.29829591512680054}}, {{0.3538379669189453}, 
          {-0.31024253368377686}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.1354455202817917, 0.1467515230178833}, "Real32"]|>, 
      "Parameters" -> <|"OutputChannels" -> 2, "KernelSize" -> {1}, 
        "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, "Dilation" -> {1}, 
        "ChannelGroups" -> 1, "Dimensionality" -> 1, "Interleaving" -> False, 
        "$InputChannels" -> 2, "$InputSize" -> {9}, "$OutputSize" -> {9}, 
        "$WeightsInputChannels" -> 2|>, "Inputs" -> 
       <|"Input" -> NeuralNetworks`TensorT[{2, 9}, NeuralNetworks`RealT]|>, 
      "Outputs" -> <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "11" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.39262712001800537}, 
          {0.32487693428993225}}, {{1.8001048564910889}, 
          {-0.6266825795173645}}}, "Real32"], "Biases" -> 
         NumericArray[{0.15029814839363098, -0.1424059271812439}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "12" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.095514677464962}, 
          {0.20944499969482422}}, {{0.18879181146621704}, 
          {-0.434833824634552}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.3515157699584961, -0.1462332159280777}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "13" -> <|"Type" -> "Pooling", 
      "Arrays" -> <||>, "Parameters" -> <|"KernelSize" -> {2}, 
        "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, "Function" -> Max, 
        "Dimensionality" -> 1, "Interleaving" -> False, "$Channels" -> 2, 
        "$InputSize" -> {9}, "$OutputSize" -> {8}, "$MXPoolingConvention" -> 
         "valid", "$MXGlobalPool" -> False, "$IgnorePadding" -> False, 
        "$InputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT], 
        "$OutputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT]|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 8}, 
          NeuralNetworks`RealT]|>|>, "14" -> <|"Type" -> "Flatten", 
      "Arrays" -> <||>, "Parameters" -> <|"Level" -> Infinity|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 8}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{16}, NeuralNetworks`RealT]|>|>, 
    "15" -> <|"Type" -> "Linear", "Arrays" -> 
       <|"Weights" -> NumericArray[{{0.035761356353759766, 
          0.05574718862771988, -0.0513579286634922, 0.15769603848457336, 
          -0.11158277094364166, 0.025602584704756737, -0.5403324961662292, 
          -0.0044409106485545635, -0.023058248683810234, 
          -0.03797304630279541, -0.024566806852817535, -0.0690411701798439, 
          0.28378042578697205, -0.2269224226474762, -0.18504361808300018, 
          -0.0313817635178566}, {-0.5334605574607849, -0.25917598605155945, 
          -0.012075509876012802, 0.08071669191122055, -0.172892227768898, 
          0.3467675447463989, -1.115147590637207, 0.18926545977592468, 
          -0.06555504351854324, 0.2678399682044983, 0.2839561998844147, 
          0.9092000722885132, -0.5403399467468262, -0.5862550735473633, 
          0.5784275531768799, -0.48035797476768494}, {0.2175351232290268, 
          0.00015946649364195764, 0.06399264931678772, -0.004669236019253731, 
          0.22786657512187958, 0.023488357663154602, 0.5457068085670471, 
          -0.006463618949055672, 0.3803982436656952, -0.7959266304969788, 
          0.13281185925006866, -0.31093621253967285, 0.019615434110164642, 
          0.17725539207458496, -0.15084871649742126, 0.18855653703212738}, 
          {0.05811155587434769, 0.11872483789920807, 0.13556645810604095, 
          0.0382687933743, -0.22963595390319824, 0.19831526279449463, 
          0.37781164050102234, 0.003319686511531472, -0.06742856651544571, 
          0.12239434570074081, 0.2475203573703766, 0.0297517292201519, 
          -0.10229934006929398, 0.05397889390587807, -0.036764487624168396, 
          0.10841567069292068}, {0.032277584075927734, 0.16486892104148865, 
          -0.10112382471561432, -0.13331051170825958, 0.25881409645080566, 
          -0.003489169292151928, 0.2309950441122055, -0.3059556186199188, 
          0.12206470966339111, -0.08728369325399399, -0.06265683472156525, 
          -0.20041389763355255, 0.34565335512161255, 0.2423652559518814, 
          -0.16937077045440674, -0.026408223435282707}, 
          {-0.07175052911043167, 0.12030480057001114, -0.19144640862941742, 
          0.2434118092060089, 0.16175109148025513, -0.2897983193397522, 
          -0.12501725554466248, 0.34877434372901917, -0.018321460112929344, 
          0.09453713148832321, -0.007948214188218117, 0.0072829024866223335, 
          -0.06537500023841858, -0.17812182009220123, 0.25978338718414307, 
          -0.05644073337316513}}, "Real32"], "Biases" -> 
         NumericArray[{-0.06358235329389572, 0.3278670012950897, 
          -0.26430487632751465, 0.045913826674222946, -0.21633034944534302, 
          0.0429791621863842}, "Real32"]|>, "Parameters" -> 
       <|"OutputDimensions" -> {6}, "$OutputSize" -> 6, "$InputSize" -> 16, 
        "$InputDimensions" -> {16}|>, "Inputs" -> 
       <|"Input" -> NeuralNetworks`TensorT[{16}, NeuralNetworks`RealT]|>, 
      "Outputs" -> <|"Output" -> NeuralNetworks`TensorT[{6}, 
          NeuralNetworks`RealT]|>|>, "16" -> <|"Type" -> "Linear", 
      "Arrays" -> <|"Weights" -> NumericArray[{{0.049276985228061676, 
          0.02859657071530819, 0.020458726212382317, -0.005424626171588898, 
          -0.008096638135612011, 0.030905477702617645}, {0.3743874728679657, 
          -0.5463224649429321, -0.3421348035335541, 0.23276351392269135, 
          0.39927157759666443, 0.20042827725410461}, {-0.3150697350502014, 
          -0.49758169054985046, 0.6824604868888855, -0.1751677542924881, 
          -0.34317532181739807, -0.170638769865036}, {-0.022641140967607498, 
          -0.013447770848870277, -0.012986190617084503, 0.024671856313943863, 
          -0.03835172578692436, 0.018446622416377068}}, "Real32"], 
        "Biases" -> NumericArray[{0.0048498413525521755, 
          -0.39424437284469604, -0.38079947233200073, -0.00699768029153347}, 
          "Real32"]|>, "Parameters" -> <|"OutputDimensions" -> {4}, 
        "$OutputSize" -> 4, "$InputSize" -> 6, "$InputDimensions" -> {6}|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{6}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{4}, NeuralNetworks`RealT]|>|>, 
    "17" -> <|"Type" -> "Linear", "Arrays" -> 
       <|"Weights" -> NumericArray[{{-0.04521002247929573, 
          -0.02271621860563755, -0.011726182885468006, 0.03497648239135742}, 
          {-0.009910034947097301, 0.5004168152809143, 0.6168245077133179, 
          0.003943017218261957}}, "Real32"], "Biases" -> 
         NumericArray[{0.01949109323322773, -0.452912837266922}, "Real32"]|>, 
      "Parameters" -> <|"OutputDimensions" -> {2}, "$OutputSize" -> 2, 
        "$InputSize" -> 4, "$InputDimensions" -> {4}|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{4}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2}, NeuralNetworks`RealT]|>|>, 
    "18" -> <|"Type" -> "Linear", "Arrays" -> 
       <|"Weights" -> NumericArray[{{-0.21630430221557617, 
          -0.06363213807344437}, {-0.24203667044639587, 0.5017400979995728}}, 
          "Real32"], "Biases" -> NumericArray[{0.6069210171699524, 
          -0.6069511771202087}, "Real32"]|>, "Parameters" -> 
       <|"OutputDimensions" -> {2}, "$OutputSize" -> 2, "$InputSize" -> 2, 
        "$InputDimensions" -> {2}|>, "Inputs" -> 
       <|"Input" -> NeuralNetworks`TensorT[{2}, NeuralNetworks`RealT]|>, 
      "Outputs" -> <|"Output" -> NeuralNetworks`TensorT[{2}, 
          NeuralNetworks`RealT]|>|>, "19" -> <|"Type" -> "Softmax", 
      "Arrays" -> <||>, "Parameters" -> <|"Level" -> -1|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2}, NeuralNetworks`RealT]|>|>|>, 
  "Edges" -> {NeuralNetworks`NetPath["Nodes", "1", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Inputs", "Input"], 
    NeuralNetworks`NetPath["Nodes", "2", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "1", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "3", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "2", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "4", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "3", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "5", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "4", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "6", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "5", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "7", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "6", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "8", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "7", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "9", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "8", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "10", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "9", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "11", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "10", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "12", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "11", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "13", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "12", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "14", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "13", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "15", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "14", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "16", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "15", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "17", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "16", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "18", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "17", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "19", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "18", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Outputs", "Output"] -> NeuralNetworks`NetPath[
      "Nodes", "19", "Outputs", "Output"]}, 
  "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
      NeuralNetworks`AtomT]|>, "Outputs" -> 
   <|"Output" -> NetDecoder["Class", <|"Labels" -> {"False", "True"}, 
       "InputDepth" -> 1, "Multilabel" -> False, "Dimensions" -> 2, 
       "$Rank" -> 0, "$Version" -> "13.0.3"|>, NeuralNetworks`TensorT[{2}, 
       NeuralNetworks`RealT]]|>|>, <|"Version" -> "13.0.3", 
  "Unstable" -> False|>]
