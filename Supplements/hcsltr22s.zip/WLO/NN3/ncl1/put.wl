NetChain[<|"Type" -> "Chain", "Nodes" -> 
   <|"1" -> <|"Type" -> "Graph", "Inputs" -> 
       <|"Input" -> NeuralNetworks`TensorT[{1, 1}, NeuralNetworks`AtomT]|>, 
      "Outputs" -> <|"Output" -> NeuralNetworks`TensorT[{2, 10}, 
          NeuralNetworks`RealT]|>, "Nodes" -> 
       <|"c01" -> <|"Type" -> "Convolution", "Arrays" -> 
           <|"Weights" -> NumericArray[{{{1.1674071550369263}}, 
              {{-0.46042168140411377}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.6596516370773315, 0.3363480865955353}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c11" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.18886134028434753}}, 
              {{0.15002873539924622}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.007109019439667463, -0.007001262158155441}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c21" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.7519432902336121}}, 
              {{-0.1283920854330063}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.5052130222320557, 0.4040094017982483}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c31" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.1614925861358643}}, 
              {{-0.9675431847572327}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.012655134312808514, -0.006469462998211384}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c41" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.7329274415969849}}, 
              {{-0.43393781781196594}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.13609571754932404, 0.1670401245355606}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c51" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.4076136350631714}}, 
              {{-1.6012463569641113}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.41188398003578186, -0.45168715715408325}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c61" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.00977106112986803}}, 
              {{0.024098550900816917}}}, "Real32"], "Biases" -> 
             NumericArray[{0.0061978851445019245, 0.016451459378004074}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c71" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.190144419670105}}, 
              {{-0.1518660932779312}}}, "Real32"], "Biases" -> 
             NumericArray[{0.5902869701385498, 0.5380409955978394}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c81" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.9728526473045349}}, 
              {{0.3102451264858246}}}, "Real32"], "Biases" -> 
             NumericArray[{0.3094669580459595, -0.2502833902835846}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c91" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.7412232160568237}}, 
              {{-0.013201636262238026}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.057770781219005585, 0.002024679211899638}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c02" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.1344749927520752}, 
              {1.047829508781433}}, {{-0.46204012632369995}, 
              {-0.5768211483955383}}}, "Real32"], "Biases" -> 
             NumericArray[{0.3713081479072571, -0.04839140176773071}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c12" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.8246429562568665}, 
              {-1.1075150966644287}}, {{0.1210150197148323}, 
              {0.1869957000017166}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.017222199589014053, 0.006068049464374781}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c22" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.0731058195233345}, 
              {-0.45150619745254517}}, {{-1.3752743005752563}, 
              {0.1802005022764206}}}, "Real32"], "Biases" -> 
             NumericArray[{0.2061208039522171, 0.4617336690425873}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c32" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.43390265107154846}, 
              {-0.4705009162425995}}, {{-0.13484205305576324}, 
              {-0.25723594427108765}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.002916230820119381, 0.019438687711954117}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c42" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.9073138236999512}, 
              {0.46009692549705505}}, {{-1.3169500827789307}, 
              {0.4557039439678192}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.1507405787706375, 0.11249081045389175}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c52" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.6356610059738159}, 
              {1.102236032485962}}, {{-0.7211474180221558}, 
              {-0.17893283069133759}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.4138944745063782, 0.3512836992740631}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c62" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.10745149850845337}, 
              {-0.48233360052108765}}, {{0.2038162350654602}, 
              {-1.0217885971069336}}}, "Real32"], "Biases" -> 
             NumericArray[{0.0033125951886177063, -0.001513151335529983}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c72" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-2.1016993522644043}, 
              {-1.5488814115524292}}, {{-0.21570448577404022}, 
              {-0.281355619430542}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.5595905184745789, -0.34266892075538635}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c82" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.421275794506073}, 
              {0.7587096691131592}}, {{-0.48370233178138733}, 
              {0.37890514731407166}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.19254742562770844, -0.2011263221502304}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c92" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.0900053977966309}, 
              {-0.16326160728931427}}, {{0.6611877083778381}, 
              {-0.28571927547454834}}}, "Real32"], "Biases" -> 
             NumericArray[{0.02709324099123478, -0.05412735044956207}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c03" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.26473045349121094}, 
              {0.06667757034301758}}, {{-1.1021983623504639}, 
              {0.28047776222229004}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.36576125025749207, -0.13576450943946838}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c13" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.9250253438949585}, 
              {0.3394622206687927}}, {{0.1683645397424698}, 
              {1.8129202127456665}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.003074208041653037, 0.004800808150321245}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c23" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.45800554752349854}, 
              {0.13899901509284973}}, {{0.12567836046218872}, 
              {1.2581967115402222}}}, "Real32"], "Biases" -> 
             NumericArray[{0.17614881694316864, 0.4296780526638031}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c33" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.0080219507217407}, 
              {0.1353495717048645}}, {{-0.39696577191352844}, 
              {-0.05180104076862335}}}, "Real32"], "Biases" -> 
             NumericArray[{0.0033170520327985287, -0.0032088179141283035}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c43" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.24367736279964447}, 
              {-1.4760305881500244}}, {{-0.750037431716919}, 
              {0.8626984357833862}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.09284652024507523, 0.12166671454906464}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c53" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.2847791314125061}, 
              {0.7215149998664856}}, {{-0.5327200889587402}, 
              {0.32709118723869324}}}, "Real32"], "Biases" -> 
             NumericArray[{0.3086511790752411, 0.35007116198539734}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c63" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.24071575701236725}, 
              {0.11935967952013016}}, {{1.1046139001846313}, 
              {-0.5462877750396729}}}, "Real32"], "Biases" -> 
             NumericArray[{0.0013937788316980004, -0.0030184078495949507}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c73" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.052054762840271}, 
              {-0.33567070960998535}}, {{0.7678543925285339}, 
              {-0.13432295620441437}}}, "Real32"], "Biases" -> 
             NumericArray[{0.5453518033027649, -0.36537107825279236}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c83" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.9512458443641663}, 
              {1.1127351522445679}}, {{0.9307485818862915}, 
              {-0.823050320148468}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.19279980659484863, -0.08864691108465195}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c93" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.9657512903213501}, 
              {-0.5679741501808167}}, {{-0.06620212644338608}, 
              {0.0464206300675869}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.020163122564554214, 0.004936958197504282}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c04" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.2038397490978241}, 
              {0.28664082288742065}}, {{-0.14015379548072815}, 
              {-0.9889806509017944}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.005298570729792118, 0.23829731345176697}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c14" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.05971773341298103}, 
              {-0.13526077568531036}}, {{0.001986375078558922}, 
              {-0.0052168103866279125}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.0014227828942239285, -0.045156653970479965}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c24" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.0814950093626976}, 
              {0.22574278712272644}}, {{-0.07807717472314835}, 
              {0.9325058460235596}}}, "Real32"], "Biases" -> 
             NumericArray[{0.3504083752632141, 0.38059738278388977}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c34" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.0004983042599633336}, 
              {0.0015608009416610003}}, {{-0.12010251730680466}, 
              {-0.31845763325691223}}}, "Real32"], "Biases" -> 
             NumericArray[{0.0008595664985477924, -0.00040195565088652074}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c44" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.4276278018951416}, 
              {0.6373493671417236}}, {{0.6866642832756042}, 
              {-0.39620888233184814}}}, "Real32"], "Biases" -> 
             NumericArray[{0.007535296492278576, -0.07033432275056839}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c54" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.20256732404232025}, 
              {0.9491282105445862}}, {{-0.2549597918987274}, 
              {-1.5829018354415894}}}, "Real32"], "Biases" -> 
             NumericArray[{0.0682394877076149, -0.33737871050834656}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c64" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.5060813426971436}, 
              {-0.7024424076080322}}, {{-0.21098336577415466}, 
              {-0.29246389865875244}}}, "Real32"], "Biases" -> 
             NumericArray[{0.04176986962556839, -0.10628911107778549}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c74" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.880647897720337}, 
              {0.9204959869384766}}, {{0.0302438884973526}, 
              {-1.5779974460601807}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.5332528948783875, 0.28745803236961365}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c84" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.15344318747520447}, 
              {0.11263597011566162}}, {{1.4084690809249878}, 
              {0.09185037016868591}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.11630859971046448, -0.18773630261421204}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c94" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.7907809019088745}, 
              {-0.18807829916477203}}, {{0.020907849073410034}, 
              {0.38531818985939026}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.09986124187707901, 0.00037909840466454625}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c05" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.1325187683105469}, 
              {-0.3160286545753479}}, {{0.6176724433898926}, 
              {-0.8743126392364502}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.26912829279899597, -0.09337364882230759}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c15" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.004591572564095259}, 
              {-0.424043208360672}}, {{-0.04100571945309639}, 
              {-0.21496404707431793}}}, "Real32"], "Biases" -> 
             NumericArray[{0.09149149060249329, -0.045363638550043106}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c25" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.0892658233642578}, 
              {-0.855201005935669}}, {{0.4092380702495575}, 
              {0.027089523151516914}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.3564366400241852, 0.13352446258068085}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c35" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.0006288798176683486}, 
              {-0.00011835574696306139}}, {{-0.0008596836705692112}, 
              {0.0007555498159490526}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.021255850791931152, 0.18310648202896118}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c45" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.14678606390953064}, 
              {0.639627993106842}}, {{0.3715476393699646}, 
              {0.26373040676116943}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.052481964230537415, 0.12468241900205612}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c55" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.3465487062931061}, 
              {0.4742780327796936}}, {{-1.1261245012283325}, 
              {0.16740640997886658}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.3112175464630127, 0.3401772975921631}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c65" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.33565133810043335}, 
              {-0.7640817761421204}}, {{0.5296841859817505}, 
              {-1.1739245653152466}}}, "Real32"], "Biases" -> 
             NumericArray[{0.14819695055484772, 0.1763376146554947}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c75" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.27566230297088623}, 
              {0.604416012763977}}, {{0.5480586290359497}, 
              {-0.9968275427818298}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.18679463863372803, -0.5586267113685608}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c85" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.12400318682193756}, 
              {-0.08103272318840027}}, {{-0.7119666934013367}, 
              {1.1348977088928223}}}, "Real32"], "Biases" -> 
             NumericArray[{0.2594120502471924, -0.13851183652877808}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c95" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.10742699354887009}, 
              {0.30270594358444214}}, {{-1.1343656778335571}, 
              {-0.004579821135848761}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.1973944902420044, 0.17078910768032074}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "output" -> <|"Type" -> "Catenate", 
          "Arrays" -> <||>, "Parameters" -> <|"Level" -> 2|>, 
          "Inputs" -> <|"Input1" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT], "Input2" -> NeuralNetworks`TensorT[
              {2, 1}, NeuralNetworks`RealT], "Input3" -> 
             NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input4" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input5" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input6" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input7" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input8" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input9" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input10" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 10}, 
              NeuralNetworks`RealT]|>|>|>, "Edges" -> 
       {NeuralNetworks`NetPath["Nodes", "c01", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c11", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c21", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c31", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c41", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c51", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c61", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c71", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c81", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c91", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c02", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c01", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c12", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c11", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c22", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c21", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c32", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c31", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c42", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c41", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c52", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c51", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c62", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c61", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c72", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c71", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c82", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c81", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c92", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c91", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c03", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c02", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c13", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c12", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c23", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c22", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c33", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c32", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c43", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c42", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c53", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c52", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c63", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c62", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c73", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c72", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c83", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c82", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c93", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c92", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c04", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c03", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c14", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c13", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c24", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c23", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c34", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c33", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c44", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c43", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c54", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c53", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c64", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c63", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c74", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c73", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c84", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c83", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c94", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c93", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c05", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c04", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c15", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c14", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c25", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c24", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c35", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c34", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c45", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c44", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c55", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c54", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c65", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c64", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c75", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c74", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c85", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c84", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c95", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c94", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input1"] -> 
         NeuralNetworks`NetPath["Nodes", "c05", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input2"] -> 
         NeuralNetworks`NetPath["Nodes", "c15", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input3"] -> 
         NeuralNetworks`NetPath["Nodes", "c25", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input4"] -> 
         NeuralNetworks`NetPath["Nodes", "c35", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input5"] -> 
         NeuralNetworks`NetPath["Nodes", "c45", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input6"] -> 
         NeuralNetworks`NetPath["Nodes", "c55", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input7"] -> 
         NeuralNetworks`NetPath["Nodes", "c65", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input8"] -> 
         NeuralNetworks`NetPath["Nodes", "c75", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input9"] -> 
         NeuralNetworks`NetPath["Nodes", "c85", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input10"] -> 
         NeuralNetworks`NetPath["Nodes", "c95", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Outputs", "Output"] -> NeuralNetworks`NetPath[
          "Nodes", "output", "Outputs", "Output"]}|>, 
    "2" -> <|"Type" -> "Pooling", "Arrays" -> <||>, 
      "Parameters" -> <|"KernelSize" -> {2}, "Stride" -> {1}, 
        "PaddingSize" -> {{0, 0}}, "Function" -> Max, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$Channels" -> 2, "$InputSize" -> {10}, 
        "$OutputSize" -> {9}, "$MXPoolingConvention" -> "valid", 
        "$MXGlobalPool" -> False, "$IgnorePadding" -> False, 
        "$InputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT], 
        "$OutputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT]|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 10}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "3" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.0008195763221010566}, 
          {-0.0007360166637226939}}, {{-1.1615915298461914}, 
          {0.47105643153190613}}}, "Real32"], "Biases" -> 
         NumericArray[{0.000964807637501508, 0.014576081186532974}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "4" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.015204822644591331}, 
          {-0.6944040656089783}}, {{-0.0294533371925354}, 
          {0.5355638861656189}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.0108039490878582, 0.01605253666639328}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "5" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.7931522727012634}, 
          {0.05272631719708443}}, {{-0.7954868674278259}, 
          {0.6981246471405029}}}, "Real32"], "Biases" -> 
         NumericArray[{0.007897783070802689, 0.014254354871809483}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "6" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.18128755688667297}, 
          {0.11402024328708649}}, {{-0.8984530568122864}, 
          {-0.9143012762069702}}}, "Real32"], "Biases" -> 
         NumericArray[{0.0001723822351777926, -0.005277544725686312}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "7" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.04440201446413994}, 
          {0.3148951530456543}}, {{0.02591709978878498}, 
          {-0.2904127836227417}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.0038153985515236855, 0.0013499080669134855}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "8" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{1.0383120775222778}, 
          {-0.7204896807670593}}, {{0.8322975635528564}, 
          {0.5072780251502991}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.0015861260471865535, 0.00046872542588971555}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "9" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-1.6931283473968506}, 
          {1.0439280271530151}}, {{-0.4329386353492737}, 
          {-0.005510574206709862}}}, "Real32"], "Biases" -> 
         NumericArray[{0.001382896094582975, 0.002269123215228319}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "10" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.6513115167617798}, 
          {0.33677735924720764}}, {{1.1729110479354858}, 
          {0.4366816580295563}}}, "Real32"], "Biases" -> 
         NumericArray[{0.03907677158713341, -0.006332515273243189}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "11" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-1.0091357231140137}, 
          {0.5818143486976624}}, {{0.46742141246795654}, 
          {0.37347927689552307}}}, "Real32"], "Biases" -> 
         NumericArray[{0.03618541732430458, 0.0009213690645992756}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "12" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.001382843591272831}, 
          {0.8263425827026367}}, {{0.0015558968298137188}, 
          {0.009959250688552856}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.009057899937033653, -0.0021187018137425184}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "13" -> <|"Type" -> "Pooling", 
      "Arrays" -> <||>, "Parameters" -> <|"KernelSize" -> {2}, 
        "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, "Function" -> Max, 
        "Dimensionality" -> 1, "Interleaving" -> False, "$Channels" -> 2, 
        "$InputSize" -> {9}, "$OutputSize" -> {8}, "$MXPoolingConvention" -> 
         "valid", "$MXGlobalPool" -> False, "$IgnorePadding" -> False, 
        "$InputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT], 
        "$OutputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT]|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 8}, 
          NeuralNetworks`RealT]|>|>, "14" -> <|"Type" -> "Flatten", 
      "Arrays" -> <||>, "Parameters" -> <|"Level" -> Infinity|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 8}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{16}, NeuralNetworks`RealT]|>|>, 
    "15" -> <|"Type" -> "Linear", "Arrays" -> 
       <|"Weights" -> NumericArray[{{0.003805951913818717, 
          0.21148213744163513, -0.027916988357901573, 0.11239084601402283, 
          -0.21438714861869812, -0.3028680086135864, 0.1891983598470688, 
          0.030251329764723778, -0.8062769174575806, -0.11288636922836304, 
          0.26257067918777466, -0.08691609650850296, 0.5101321935653687, 
          -0.06560908257961273, 0.12503089010715485, 0.26602208614349365}, 
          {-0.14617620408535004, 0.25806280970573425, -0.25883302092552185, 
          -0.018942905589938164, 0.04566613584756851, -0.06218092516064644, 
          0.08714231848716736, 0.01047722902148962, -0.3013608157634735, 
          0.24397540092468262, 0.2720087170600891, 0.09647523611783981, 
          -0.31131523847579956, -0.24718008935451508, 0.1977439671754837, 
          0.1158614307641983}, {0.09700224548578262, -0.02059515193104744, 
          -0.3330621123313904, 0.0346350334584713, 0.267019122838974, 
          0.2114647775888443, -0.06873949617147446, 0.13886107504367828, 
          -0.027200259268283844, -0.4678264558315277, -0.27167367935180664, 
          -0.3099142909049988, -0.1252002865076065, 0.21850980818271637, 
          0.02588198520243168, -0.05252876132726669}, {-0.42972514033317566, 
          0.48800399899482727, 0.5442476868629456, -0.11895821988582611, 
          0.12949585914611816, -0.16129271686077118, -0.38276997208595276, 
          -0.5132896900177002, 0.016304822638630867, 0.10429631173610687, 
          0.16566412150859833, 0.12274453043937683, 0.43925243616104126, 
          0.2664167284965515, -0.28207284212112427, 0.033302340656518936}, 
          {0.2763645350933075, -0.46149367094039917, -0.15695135295391083, 
          -0.7908889055252075, -0.03518713638186455, 0.4273984730243683, 
          -0.037344131618738174, 0.4422067701816559, -0.14771269261837006, 
          0.16420668363571167, -0.08774282038211823, -0.06275799125432968, 
          0.6928854584693909, 0.4835521876811981, 0.15703588724136353, 
          -0.1552167683839798}, {-0.06726552546024323, -0.21814167499542236, 
          -0.22621768712997437, -0.08744800090789795, -0.2038256824016571, 
          -0.036346133798360825, 0.3652994632720947, 0.21300186216831207, 
          0.04514294117689133, 0.12192567437887192, 0.19129949808120728, 
          0.06971684843301773, -0.10984804481267929, -0.15277573466300964, 
          -0.565198540687561, 0.15893132984638214}}, "Real32"], 
        "Biases" -> NumericArray[{-0.027495890855789185, 
          -0.0005877088406123221, 0.007957295514643192, 0.11718498915433884, 
          -0.13748207688331604, -0.15588819980621338}, "Real32"]|>, 
      "Parameters" -> <|"OutputDimensions" -> {6}, "$OutputSize" -> 6, 
        "$InputSize" -> 16, "$InputDimensions" -> {16}|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{16}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{6}, NeuralNetworks`RealT]|>|>, 
    "16" -> <|"Type" -> "Linear", "Arrays" -> 
       <|"Weights" -> NumericArray[{{-0.04796688258647919, 
          -0.050265856087207794, -1.0493520498275757, -0.5241212844848633, 
          -0.0359078086912632, -0.5545582175254822}, {-0.2270967960357666, 
          0.23399606347084045, 0.16814397275447845, 0.2654971480369568, 
          -0.2029663324356079, -0.6900606155395508}, {0.2891671359539032, 
          -0.31365230679512024, -0.2085384875535965, 0.2341068685054779, 
          -0.3004175126552582, 0.4311092495918274}, {0.0007122459355741739, 
          -0.03030165657401085, 0.3597886264324188, 0.13097187876701355, 
          -0.0026179086416959763, 0.11506057530641556}}, "Real32"], 
        "Biases" -> NumericArray[{-0.021567415446043015, 0.17177315056324005, 
          0.1478825956583023, -0.004014973063021898}, "Real32"]|>, 
      "Parameters" -> <|"OutputDimensions" -> {4}, "$OutputSize" -> 4, 
        "$InputSize" -> 6, "$InputDimensions" -> {6}|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{6}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{4}, NeuralNetworks`RealT]|>|>, 
    "17" -> <|"Type" -> "Linear", "Arrays" -> 
       <|"Weights" -> NumericArray[{{-0.43903908133506775, 
          -0.36251774430274963, 0.4874227046966553, 0.621846616268158}, 
          {-0.1101580485701561, -0.9142206907272339, -0.5006681084632874, 
          0.15744554996490479}}, "Real32"], "Biases" -> 
         NumericArray[{0.1442164182662964, -0.19071456789970398}, 
          "Real32"]|>, "Parameters" -> <|"OutputDimensions" -> {2}, 
        "$OutputSize" -> 2, "$InputSize" -> 4, "$InputDimensions" -> {4}|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{4}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2}, NeuralNetworks`RealT]|>|>, 
    "18" -> <|"Type" -> "Linear", "Arrays" -> 
       <|"Weights" -> NumericArray[{{-0.15167176723480225, 
          -1.3372889757156372}, {-0.5440454483032227, 0.13013626635074615}}, 
          "Real32"], "Biases" -> NumericArray[{0.2180917114019394, 
          -0.2181067168712616}, "Real32"]|>, "Parameters" -> 
       <|"OutputDimensions" -> {2}, "$OutputSize" -> 2, "$InputSize" -> 2, 
        "$InputDimensions" -> {2}|>, "Inputs" -> 
       <|"Input" -> NeuralNetworks`TensorT[{2}, NeuralNetworks`RealT]|>, 
      "Outputs" -> <|"Output" -> NeuralNetworks`TensorT[{2}, 
          NeuralNetworks`RealT]|>|>, "19" -> <|"Type" -> "Softmax", 
      "Arrays" -> <||>, "Parameters" -> <|"Level" -> -1|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2}, NeuralNetworks`RealT]|>|>|>, 
  "Edges" -> {NeuralNetworks`NetPath["Nodes", "1", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Inputs", "Input"], 
    NeuralNetworks`NetPath["Nodes", "2", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "1", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "3", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "2", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "4", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "3", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "5", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "4", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "6", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "5", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "7", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "6", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "8", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "7", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "9", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "8", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "10", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "9", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "11", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "10", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "12", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "11", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "13", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "12", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "14", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "13", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "15", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "14", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "16", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "15", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "17", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "16", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "18", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "17", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "19", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "18", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Outputs", "Output"] -> NeuralNetworks`NetPath[
      "Nodes", "19", "Outputs", "Output"]}, 
  "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
      NeuralNetworks`AtomT]|>, "Outputs" -> 
   <|"Output" -> NetDecoder["Class", <|"Labels" -> {"False", "True"}, 
       "InputDepth" -> 1, "Multilabel" -> False, "Dimensions" -> 2, 
       "$Rank" -> 0, "$Version" -> "13.0.3"|>, NeuralNetworks`TensorT[{2}, 
       NeuralNetworks`RealT]]|>|>, <|"Version" -> "13.0.3", 
  "Unstable" -> False|>]
