NetChain[<|"Type" -> "Chain", "Nodes" -> 
   <|"1" -> <|"Type" -> "Graph", "Inputs" -> 
       <|"Input" -> NeuralNetworks`TensorT[{1, 1}, NeuralNetworks`AtomT]|>, 
      "Outputs" -> <|"Output" -> NeuralNetworks`TensorT[{2, 10}, 
          NeuralNetworks`RealT]|>, "Nodes" -> 
       <|"c01" -> <|"Type" -> "Convolution", "Arrays" -> 
           <|"Weights" -> NumericArray[{{{-0.5103513598442078}}, 
              {{0.5121344327926636}}}, "Real32"], "Biases" -> 
             NumericArray[{0.06738446652889252, -0.07730495184659958}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c11" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.29743924736976624}}, 
              {{0.9979312419891357}}}, "Real32"], "Biases" -> 
             NumericArray[{0.3085876405239105, 0.354003369808197}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c21" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.39638710021972656}}, 
              {{-1.0165674686431885}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.14252197742462158, -0.07600891590118408}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c31" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.1783984899520874}}, 
              {{0.40914854407310486}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.242570698261261, -0.3230973482131958}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c41" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.7713965177536011}}, 
              {{0.058378513902425766}}}, "Real32"], "Biases" -> 
             NumericArray[{0.17739929258823395, -0.0856151282787323}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c51" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.22762556374073029}}, 
              {{1.0985774993896484}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.022597774863243103, 0.1119488850235939}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c61" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.7553116083145142}}, 
              {{1.1821480989456177}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.045012153685092926, -0.12582284212112427}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c71" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.2734730839729309}}, 
              {{-1.0297715663909912}}}, "Real32"], "Biases" -> 
             NumericArray[{0.31691303849220276, 0.28674599528312683}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c81" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.6804250478744507}}, 
              {{0.8718727827072144}}}, "Real32"], "Biases" -> 
             NumericArray[{0.006141222082078457, -0.03436247259378433}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c91" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.547787070274353}}, 
              {{-1.0335921049118042}}}, "Real32"], "Biases" -> 
             NumericArray[{0.0594446137547493, 0.10651055723428726}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c02" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.01864338293671608}, 
              {1.7260994911193848}}, {{-0.33837300539016724}, 
              {0.8007717132568359}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.08159604668617249, -0.04621392861008644}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c12" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.1561503410339355}, 
              {0.21875779330730438}}, {{-0.20282822847366333}, 
              {0.358572393655777}}}, "Real32"], "Biases" -> 
             NumericArray[{0.2575743794441223, 0.25914913415908813}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c22" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.2535986006259918}, 
              {-0.4140544533729553}}, {{-0.7121977806091309}, 
              {0.08849775791168213}}}, "Real32"], "Biases" -> 
             NumericArray[{0.12078804522752762, 0.1564888060092926}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c32" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.28686532378196716}, 
              {-1.2591376304626465}}, {{0.19871088862419128}, 
              {-0.039449628442525864}}}, "Real32"], "Biases" -> 
             NumericArray[{0.32477930188179016, 0.2860059440135956}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c42" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.29261791706085205}, 
              {-1.0918128490447998}}, {{1.271201729774475}, 
              {-0.26052960753440857}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.17031659185886383, 0.17031149566173553}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c52" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.4144155979156494}, 
              {-0.08625318855047226}}, {{-0.19463641941547394}, 
              {0.5884056687355042}}}, "Real32"], "Biases" -> 
             NumericArray[{0.01856967620551586, 0.0780717134475708}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c62" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.44473907351493835}, 
              {0.7793242335319519}}, {{-0.5599165558815002}, 
              {-0.04147954285144806}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.10758726298809052, 0.0031660397071391344}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c72" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.6490004062652588}, 
              {-0.8935359716415405}}, {{0.08246701955795288}, 
              {0.5061842203140259}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.2639821171760559, 0.2397627830505371}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c82" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.17020756006240845}, 
              {0.1576940417289734}}, {{0.5995649099349976}, 
              {0.48365500569343567}}}, "Real32"], "Biases" -> 
             NumericArray[{0.018979718908667564, 0.03485032171010971}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c92" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.35608571767807007}, 
              {-0.5330606698989868}}, {{0.19527266919612885}, 
              {-0.2929064631462097}}}, "Real32"], "Biases" -> 
             NumericArray[{0.03655118867754936, 0.01635543815791607}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c03" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.6783385276794434}, 
              {-1.0282031297683716}}, {{0.3919734060764313}, 
              {0.4399340748786926}}}, "Real32"], "Biases" -> 
             NumericArray[{0.004754178691655397, -0.054880291223526}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c13" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.3198291063308716}, 
              {-1.5415412187576294}}, {{-0.31638792157173157}, 
              {0.01980055682361126}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.23845013976097107, -0.2124854326248169}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c23" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.5472638607025146}, 
              {-0.7215372323989868}}, {{0.4952300488948822}, 
              {-0.7482243776321411}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.20633159577846527, -0.10665863007307053}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c33" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.09627033025026321}, 
              {-0.5740711092948914}}, {{0.7949236631393433}, 
              {0.0901966467499733}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.3481542766094208, 0.361783891916275}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c43" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.3068090081214905}, 
              {-1.3320285081863403}}, {{-0.011334743350744247}, 
              {0.4777110815048218}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.14655417203903198, 0.21478405594825745}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c53" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.0029898006469011307}, 
              {-1.263733983039856}}, {{0.0015076486160978675}, 
              {0.5064268112182617}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.09131617844104767, 0.010927058756351471}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c63" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.4784103631973267}, 
              {0.48908087611198425}}, {{0.8664524555206299}, 
              {0.2753991186618805}}}, "Real32"], "Biases" -> 
             NumericArray[{0.05311524495482445, -0.10598793625831604}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c73" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.06472582370042801}, 
              {0.9145061373710632}}, {{1.8052295446395874}, 
              {-0.1818443387746811}}}, "Real32"], "Biases" -> 
             NumericArray[{0.19740858674049377, -0.2323627471923828}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c83" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.023974459618330002}, 
              {-0.3486459255218506}}, {{-0.058418843895196915}, 
              {-0.8970097899436951}}}, "Real32"], "Biases" -> 
             NumericArray[{0.012898139655590057, -0.027443278580904007}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c93" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.2822263538837433}, 
              {-0.8990676403045654}}, {{0.5840263962745667}, 
              {-1.860397458076477}}}, "Real32"], "Biases" -> 
             NumericArray[{0.026144059374928474, -0.024243900552392006}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c04" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.084801584482193}, 
              {0.26630330085754395}}, {{-0.5786356329917908}, 
              {0.3252883553504944}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.04481082037091255, -0.10674507915973663}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c14" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.14205577969551086}, 
              {0.06687293201684952}}, {{-1.6713167428970337}, 
              {-0.5978590846061707}}}, "Real32"], "Biases" -> 
             NumericArray[{0.1972145438194275, 0.22283270955085754}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c24" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.2346603274345398}, 
              {-0.9056758284568787}}, {{0.3970802128314972}, 
              {-0.5185104012489319}}}, "Real32"], "Biases" -> 
             NumericArray[{0.21232007443904877, -0.2800939381122589}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c34" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.5784932374954224}, 
              {-1.0111958980560303}}, {{0.5130099654197693}, 
              {0.35314908623695374}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.38935503363609314, -0.32563361525535583}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c44" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.4611835181713104}, 
              {0.7793950438499451}}, {{1.6742641925811768}, 
              {-1.3617558479309082}}}, "Real32"], "Biases" -> 
             NumericArray[{0.405629426240921, -0.0656430795788765}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c54" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.0377976894378662}, 
              {-0.11746153980493546}}, {{0.40973442792892456}, 
              {-0.7530118823051453}}}, "Real32"], "Biases" -> 
             NumericArray[{0.14639407396316528, -0.02455839328467846}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c64" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.4267188608646393}, 
              {-0.3423802852630615}}, {{0.5314520597457886}, 
              {0.16250993311405182}}}, "Real32"], "Biases" -> 
             NumericArray[{0.05553033947944641, 0.16245847940444946}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c74" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.36663877964019775}, 
              {0.6164510846138}}, {{0.49609893560409546}, 
              {0.022261401638388634}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.17309269309043884, 0.1385665237903595}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c84" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.5276731252670288}, 
              {-0.17718347907066345}}, {{-0.9059398174285889}, 
              {-0.44630393385887146}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.16096614301204681, 0.11054006218910217}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c94" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.1880970001220703}, 
              {0.3650071620941162}}, {{-0.2730509340763092}, 
              {0.21500326693058014}}}, "Real32"], "Biases" -> 
             NumericArray[{0.030062152072787285, -0.044721465557813644}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c05" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.0741676539182663}, 
              {0.8669546246528625}}, {{-0.16784904897212982}, 
              {-0.19147203862667084}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.10359841585159302, 0.1365060806274414}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c15" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.5836464166641235}, 
              {-1.1672149896621704}}, {{-0.01674565114080906}, 
              {-0.883472740650177}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.2042514979839325, -0.2066536694765091}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c25" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.3528089225292206}, 
              {-0.807726263999939}}, {{-0.7389572262763977}, 
              {0.43296289443969727}}}, "Real32"], "Biases" -> 
             NumericArray[{0.1828216314315796, -0.1150483563542366}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c35" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{2.1079089641571045}, 
              {0.06407923996448517}}, {{-0.7709406614303589}, 
              {-0.4311297535896301}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.20880217850208282, 0.32671624422073364}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c45" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.6155707240104675}, 
              {-0.6739413738250732}}, {{-0.3123232424259186}, 
              {0.6788391470909119}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.33494269847869873, -0.3493233025074005}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c55" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.739651083946228}, 
              {0.9771033525466919}}, {{-0.3464002311229706}, 
              {0.6464868187904358}}}, "Real32"], "Biases" -> 
             NumericArray[{0.22395391762256622, -0.07965268194675446}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c65" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.47759100794792175}, 
              {-0.49159279465675354}}, {{0.2630293667316437}, 
              {0.39042627811431885}}}, "Real32"], "Biases" -> 
             NumericArray[{0.08540666103363037, 0.17394514381885529}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c75" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.141401767730713}, 
              {1.4880000352859497}}, {{1.7874646186828613}, 
              {-1.3878448009490967}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.13952043652534485, -0.16280953586101532}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c85" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.4784184694290161}, 
              {0.5213484764099121}}, {{0.10279238969087601}, 
              {-0.24876397848129272}}}, "Real32"], "Biases" -> 
             NumericArray[{0.2842561602592468, 0.20748327672481537}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c95" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.0750684067606926}, 
              {0.0631709024310112}}, {{0.13823406398296356}, 
              {-0.7646774649620056}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.1249251514673233, 0.05410923808813095}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "output" -> <|"Type" -> "Catenate", 
          "Arrays" -> <||>, "Parameters" -> <|"Level" -> 2|>, 
          "Inputs" -> <|"Input1" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT], "Input2" -> NeuralNetworks`TensorT[
              {2, 1}, NeuralNetworks`RealT], "Input3" -> 
             NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input4" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input5" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input6" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input7" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input8" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input9" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input10" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 10}, 
              NeuralNetworks`RealT]|>|>|>, "Edges" -> 
       {NeuralNetworks`NetPath["Nodes", "c01", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c11", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c21", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c31", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c41", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c51", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c61", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c71", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c81", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c91", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c02", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c01", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c12", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c11", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c22", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c21", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c32", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c31", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c42", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c41", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c52", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c51", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c62", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c61", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c72", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c71", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c82", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c81", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c92", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c91", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c03", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c02", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c13", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c12", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c23", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c22", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c33", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c32", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c43", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c42", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c53", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c52", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c63", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c62", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c73", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c72", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c83", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c82", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c93", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c92", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c04", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c03", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c14", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c13", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c24", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c23", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c34", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c33", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c44", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c43", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c54", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c53", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c64", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c63", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c74", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c73", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c84", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c83", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c94", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c93", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c05", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c04", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c15", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c14", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c25", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c24", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c35", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c34", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c45", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c44", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c55", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c54", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c65", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c64", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c75", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c74", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c85", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c84", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c95", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c94", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input1"] -> 
         NeuralNetworks`NetPath["Nodes", "c05", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input2"] -> 
         NeuralNetworks`NetPath["Nodes", "c15", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input3"] -> 
         NeuralNetworks`NetPath["Nodes", "c25", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input4"] -> 
         NeuralNetworks`NetPath["Nodes", "c35", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input5"] -> 
         NeuralNetworks`NetPath["Nodes", "c45", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input6"] -> 
         NeuralNetworks`NetPath["Nodes", "c55", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input7"] -> 
         NeuralNetworks`NetPath["Nodes", "c65", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input8"] -> 
         NeuralNetworks`NetPath["Nodes", "c75", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input9"] -> 
         NeuralNetworks`NetPath["Nodes", "c85", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input10"] -> 
         NeuralNetworks`NetPath["Nodes", "c95", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Outputs", "Output"] -> NeuralNetworks`NetPath[
          "Nodes", "output", "Outputs", "Output"]}|>, 
    "2" -> <|"Type" -> "Pooling", "Arrays" -> <||>, 
      "Parameters" -> <|"KernelSize" -> {2}, "Stride" -> {1}, 
        "PaddingSize" -> {{0, 0}}, "Function" -> Max, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$Channels" -> 2, "$InputSize" -> {10}, 
        "$OutputSize" -> {9}, "$MXPoolingConvention" -> "valid", 
        "$MXGlobalPool" -> False, "$IgnorePadding" -> False, 
        "$InputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT], 
        "$OutputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT]|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 10}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "3" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.32740968465805054}, 
          {1.1652376651763916}}, {{0.8602610230445862}, 
          {-0.023914534598588943}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.05307481065392494, -0.06389588117599487}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "4" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-1.0136871337890625}, 
          {-0.9051390886306763}}, {{-0.00873404648154974}, 
          {-0.5938394665718079}}}, "Real32"], "Biases" -> 
         NumericArray[{0.05538090318441391, 0.06179178133606911}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "5" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.18703481554985046}, 
          {0.20516814291477203}}, {{-1.6354652643203735}, 
          {-0.8429851531982422}}}, "Real32"], "Biases" -> 
         NumericArray[{0.05638045072555542, -0.05322020500898361}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "6" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.18982325494289398}, 
          {-0.025141797959804535}}, {{0.27044591307640076}, 
          {-0.40814030170440674}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.035366158932447433, 0.04619026184082031}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "7" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{1.0107181072235107}, 
          {1.7771189212799072}}, {{-1.1957175731658936}, 
          {0.6114434003829956}}}, "Real32"], "Biases" -> 
         NumericArray[{0.044283024966716766, 0.04349290579557419}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "8" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.4094051122665405}, 
          {-0.19936712086200714}}, {{0.10022570192813873}, 
          {0.3008350133895874}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.03306986019015312, 0.03176707401871681}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "9" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.05289103463292122}, 
          {0.11978206783533096}}, {{-0.7028955221176147}, 
          {0.468189537525177}}}, "Real32"], "Biases" -> 
         NumericArray[{0.00329707027412951, 0.02789255604147911}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "10" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.5189872980117798}, 
          {-0.337494820356369}}, {{-0.12663887441158295}, 
          {0.43974733352661133}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.025890285149216652, 0.021435625851154327}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "11" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.6243113875389099}, 
          {1.0061222314834595}}, {{0.08602075278759003}, 
          {1.0623607635498047}}}, "Real32"], "Biases" -> 
         NumericArray[{0.01908179558813572, 0.01840897463262081}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "12" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{1.1049882173538208}, 
          {1.2270901203155518}}, {{-0.16483131051063538}, 
          {-0.1968274861574173}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.08747498691082001, -0.08983615785837173}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "13" -> <|"Type" -> "Pooling", 
      "Arrays" -> <||>, "Parameters" -> <|"KernelSize" -> {2}, 
        "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, "Function" -> Max, 
        "Dimensionality" -> 1, "Interleaving" -> False, "$Channels" -> 2, 
        "$InputSize" -> {9}, "$OutputSize" -> {8}, "$MXPoolingConvention" -> 
         "valid", "$MXGlobalPool" -> False, "$IgnorePadding" -> False, 
        "$InputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT], 
        "$OutputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT]|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 8}, 
          NeuralNetworks`RealT]|>|>, "14" -> <|"Type" -> "Flatten", 
      "Arrays" -> <||>, "Parameters" -> <|"Level" -> Infinity|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 8}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{16}, NeuralNetworks`RealT]|>|>, 
    "15" -> <|"Type" -> "Linear", "Arrays" -> 
       <|"Weights" -> NumericArray[{{0.32877063751220703, 
          -0.2832825183868408, -0.4344300627708435, 0.27818575501441956, 
          0.03747972473502159, -0.07941336929798126, 0.12364059686660767, 
          -0.6959890723228455, -0.4293658435344696, -0.15810807049274445, 
          -0.04939214512705803, -0.5623616576194763, 0.17640140652656555, 
          -0.24747782945632935, -0.02046244777739048, 0.1387125551700592}, 
          {0.30697059631347656, -0.3294192850589752, 0.10106614232063293, 
          0.1328425109386444, -0.30468085408210754, 0.02222266048192978, 
          0.1329539716243744, -0.010517001152038574, 0.21127398312091827, 
          0.10337406396865845, 0.33732497692108154, 0.045297153294086456, 
          -0.04866325855255127, 0.3611494302749634, 0.47988361120224, 
          0.04375865310430527}, {0.15227831900119781, -0.18587128818035126, 
          -0.0987873300909996, -0.1333579123020172, 0.20080673694610596, 
          -0.775783896446228, -0.01947665773332119, 0.058314260095357895, 
          -0.05592593178153038, 0.07703907787799835, -0.2668313980102539, 
          -0.24573424458503723, -0.21582414209842682, -0.40075334906578064, 
          -0.26071062684059143, -0.0356772318482399}, {-0.17288587987422943, 
          -0.05023672431707382, -0.03314979001879692, 0.03883907198905945, 
          0.14090174436569214, -0.3037114143371582, -0.05000379681587219, 
          0.38919058442115784, -0.9863136410713196, -0.382564902305603, 
          0.12877480685710907, 0.10061109066009521, -0.26892390847206116, 
          -0.13227377831935883, -0.03258317708969116, -0.09327588230371475}, 
          {-0.2607389986515045, 0.39727190136909485, -0.10075673460960388, 
          -0.30485662817955017, 0.30175551772117615, -0.08457974344491959, 
          -0.015906937420368195, 0.7364216446876526, -0.12318579852581024, 
          0.12383212894201279, -0.04167507588863373, 0.05983208492398262, 
          -0.07713092863559723, 0.36829593777656555, -0.3330603837966919, 
          -0.17764343321323395}, {-0.5537782907485962, 0.05019894614815712, 
          0.00013240038242656738, -0.44513413310050964, 0.23406872153282166, 
          0.19700980186462402, -0.5259397625923157, 0.501399576663971, 
          0.659256100654602, -0.09838547557592392, 0.07605962455272675, 
          0.0010119160870090127, 0.025104718282818794, -0.11097264289855957, 
          0.18364962935447693, -0.3841278553009033}}, "Real32"], 
        "Biases" -> NumericArray[{0.01532739121466875, 0.16772815585136414, 
          -0.008432997390627861, -0.07114975899457932, -0.11841179430484772, 
          -0.039889365434646606}, "Real32"]|>, "Parameters" -> 
       <|"OutputDimensions" -> {6}, "$OutputSize" -> 6, "$InputSize" -> 16, 
        "$InputDimensions" -> {16}|>, "Inputs" -> 
       <|"Input" -> NeuralNetworks`TensorT[{16}, NeuralNetworks`RealT]|>, 
      "Outputs" -> <|"Output" -> NeuralNetworks`TensorT[{6}, 
          NeuralNetworks`RealT]|>|>, "16" -> <|"Type" -> "Linear", 
      "Arrays" -> <|"Weights" -> NumericArray[{{-0.09370603412389755, 
          -0.34135913848876953, 0.17693690955638885, -0.12043629586696625, 
          -0.00794095080345869, -0.041908517479896545}, {-0.716456949710846, 
          -0.01639506220817566, -0.03814610466361046, -0.03652184456586838, 
          0.19241665303707123, 0.765275239944458}, {-0.14539486169815063, 
          -0.406093567609787, 0.5642959475517273, 0.42109373211860657, 
          -0.25211966037750244, 0.8572909235954285}, {-0.4814673066139221, 
          -1.0684043169021606, 0.4964814782142639, 0.0055623906664550304, 
          -0.05026167631149292, -0.2241107076406479}}, "Real32"], 
        "Biases" -> NumericArray[{0.02089974842965603, -0.04071811959147453, 
          -0.021614139899611473, 0.10160423070192337}, "Real32"]|>, 
      "Parameters" -> <|"OutputDimensions" -> {4}, "$OutputSize" -> 4, 
        "$InputSize" -> 6, "$InputDimensions" -> {6}|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{6}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{4}, NeuralNetworks`RealT]|>|>, 
    "17" -> <|"Type" -> "Linear", "Arrays" -> 
       <|"Weights" -> NumericArray[{{0.12513607740402222, 
          -0.1722622960805893, 0.21612614393234253, -0.03640865162014961}, 
          {-0.0018001061398535967, 0.6591464281082153, 0.06994494050741196, 
          -0.03644908592104912}}, "Real32"], "Biases" -> 
         NumericArray[{-0.015921220183372498, -0.047137171030044556}, 
          "Real32"]|>, "Parameters" -> <|"OutputDimensions" -> {2}, 
        "$OutputSize" -> 2, "$InputSize" -> 4, "$InputDimensions" -> {4}|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{4}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2}, NeuralNetworks`RealT]|>|>, 
    "18" -> <|"Type" -> "Linear", "Arrays" -> 
       <|"Weights" -> NumericArray[{{-0.2524949312210083, 
          -1.092339277267456}, {-0.23980635404586792, 0.19143560528755188}}, 
          "Real32"], "Biases" -> NumericArray[{0.05345296859741211, 
          -0.05345885828137398}, "Real32"]|>, "Parameters" -> 
       <|"OutputDimensions" -> {2}, "$OutputSize" -> 2, "$InputSize" -> 2, 
        "$InputDimensions" -> {2}|>, "Inputs" -> 
       <|"Input" -> NeuralNetworks`TensorT[{2}, NeuralNetworks`RealT]|>, 
      "Outputs" -> <|"Output" -> NeuralNetworks`TensorT[{2}, 
          NeuralNetworks`RealT]|>|>, "19" -> <|"Type" -> "Softmax", 
      "Arrays" -> <||>, "Parameters" -> <|"Level" -> -1|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2}, NeuralNetworks`RealT]|>|>|>, 
  "Edges" -> {NeuralNetworks`NetPath["Nodes", "1", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Inputs", "Input"], 
    NeuralNetworks`NetPath["Nodes", "2", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "1", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "3", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "2", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "4", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "3", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "5", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "4", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "6", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "5", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "7", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "6", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "8", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "7", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "9", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "8", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "10", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "9", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "11", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "10", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "12", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "11", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "13", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "12", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "14", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "13", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "15", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "14", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "16", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "15", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "17", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "16", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "18", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "17", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "19", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "18", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Outputs", "Output"] -> NeuralNetworks`NetPath[
      "Nodes", "19", "Outputs", "Output"]}, 
  "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
      NeuralNetworks`AtomT]|>, "Outputs" -> 
   <|"Output" -> NetDecoder["Class", <|"Labels" -> {"False", "True"}, 
       "InputDepth" -> 1, "Multilabel" -> False, "Dimensions" -> 2, 
       "$Rank" -> 0, "$Version" -> "13.0.3"|>, NeuralNetworks`TensorT[{2}, 
       NeuralNetworks`RealT]]|>|>, <|"Version" -> "13.0.3", 
  "Unstable" -> False|>]
