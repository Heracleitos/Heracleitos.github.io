NetChain[<|"Type" -> "Chain", "Nodes" -> 
   <|"1" -> <|"Type" -> "Graph", "Inputs" -> 
       <|"Input" -> NeuralNetworks`TensorT[{1, 1}, NeuralNetworks`AtomT]|>, 
      "Outputs" -> <|"Output" -> NeuralNetworks`TensorT[{2, 10}, 
          NeuralNetworks`RealT]|>, "Nodes" -> 
       <|"c01" -> <|"Type" -> "Convolution", "Arrays" -> 
           <|"Weights" -> NumericArray[{{{0.8301765322685242}}, 
              {{-1.9594985246658325}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.12446682155132294, 0.09632239490747452}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c11" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.10002125799655914}}, 
              {{0.5783767104148865}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.028413815423846245, 0.2042076140642166}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c21" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.1607500314712524}}, 
              {{-0.0003487340873107314}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.7157084941864014, 0.007906469516456127}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c31" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.309826374053955}}, 
              {{-0.559838593006134}}}, "Real32"], "Biases" -> 
             NumericArray[{0.5826069712638855, -0.5994921922683716}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c41" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.000600821222178638}}, 
              {{-1.4738006591796875}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.0019301463617011905, 0.6375520825386047}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c51" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.032705556601285934}}, 
              {{-0.6508129239082336}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.09145759046077728, -0.7248014807701111}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c61" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.023551981896162033}}, 
              {{0.017525697126984596}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.027851222082972527, -0.032695263624191284}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c71" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.8810200691223145}}, 
              {{-0.14638440310955048}}}, "Real32"], "Biases" -> 
             NumericArray[{0.9391941428184509, 0.446186363697052}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c81" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.1899871826171875}}, 
              {{-1.3708981275558472}}}, "Real32"], "Biases" -> 
             NumericArray[{0.6537837386131287, -0.7790184020996094}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c91" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.4602951109409332}}, 
              {{-0.20936235785484314}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.4177663326263428, -0.03451716899871826}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 1, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 1|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
              NeuralNetworks`AtomT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c02" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.1730457544326782}, 
              {0.5014715194702148}}, {{0.43391308188438416}, 
              {0.16301825642585754}}}, "Real32"], "Biases" -> 
             NumericArray[{0.10534639656543732, 0.07696890085935593}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c12" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.6156242489814758}, 
              {0.15307679772377014}}, {{0.22949086129665375}, 
              {-0.7109877467155457}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.07910937070846558, -0.2243524044752121}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c22" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.004222473129630089}, 
              {1.5924780368804932}}, {{0.4544391334056854}, 
              {0.0017241239547729492}}}, "Real32"], "Biases" -> 
             NumericArray[{0.007127021439373493, -0.49397262930870056}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c32" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.009822964668274}, 
              {0.5142452716827393}}, {{-0.5324413776397705}, 
              {0.8017501831054688}}}, "Real32"], "Biases" -> 
             NumericArray[{0.48044055700302124, -0.45827674865722656}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c42" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.013139973394572735}, 
              {0.21623758971691132}}, {{-0.0022572085727006197}, 
              {1.227471947669983}}}, "Real32"], "Biases" -> 
             NumericArray[{0.35789647698402405, 0.5268683433532715}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c52" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.06107844412326813}, 
              {-0.49507051706314087}}, {{-0.03823591023683548}, 
              {-1.528702974319458}}}, "Real32"], "Biases" -> 
             NumericArray[{0.5638948082923889, 0.6207811236381531}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c62" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.20689594745635986}, 
              {-0.14345256984233856}}, {{-0.1299481987953186}, 
              {-0.25052493810653687}}}, "Real32"], "Biases" -> 
             NumericArray[{0.010296774096786976, 0.021098632365465164}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c72" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{1.6981987953186035}, 
              {0.39115336537361145}}, {{0.48423758149147034}, 
              {-0.3316998779773712}}}, "Real32"], "Biases" -> 
             NumericArray[{0.849036693572998, 0.7613726258277893}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c82" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.9664962291717529}, 
              {-0.5130413770675659}}, {{-1.5180753469467163}, 
              {0.8300418853759766}}}, "Real32"], "Biases" -> 
             NumericArray[{0.5534858703613281, -0.5570148229598999}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c92" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.7734467387199402}, 
              {0.44087404012680054}}, {{0.6694715023040771}, 
              {0.46462827920913696}}}, "Real32"], "Biases" -> 
             NumericArray[{0.5533233284950256, -0.6064040064811707}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c03" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.18189367651939392}, 
              {-0.3832166790962219}}, {{-0.08323083072900772}, 
              {-0.7795827984809875}}}, "Real32"], "Biases" -> 
             NumericArray[{0.09231339395046234, -0.0814882293343544}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c13" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.2378019392490387}, 
              {0.892183780670166}}, {{0.061135753989219666}, 
              {0.07354692369699478}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.18713819980621338, 0.034574590623378754}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c23" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.20551694929599762}, 
              {0.09142538160085678}}, {{0.38033369183540344}, 
              {1.7899415493011475}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.4905085265636444, -0.5244181752204895}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c33" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.8778746724128723}, 
              {-1.0061455965042114}}, {{0.20059950649738312}, 
              {0.18078072369098663}}}, "Real32"], "Biases" -> 
             NumericArray[{0.4152962863445282, 0.0741671621799469}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c43" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.7916890382766724}, 
              {1.4642624855041504}}, {{0.9282181859016418}, 
              {0.7620734572410583}}}, "Real32"], "Biases" -> 
             NumericArray[{0.6357391476631165, 0.1925738900899887}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c53" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.107067346572876}, 
              {-1.7189961671829224}}, {{0.34982770681381226}, 
              {-0.030399156734347343}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.5913611650466919, -0.005352354608476162}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c63" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.4061633348464966}, 
              {-0.5733977556228638}}, {{-0.8836029171943665}, 
              {-1.187878966331482}}}, "Real32"], "Biases" -> 
             NumericArray[{0.10823331028223038, 0.011141638271510601}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c73" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.380698323249817}, 
              {-0.3674249053001404}}, {{-0.5342352986335754}, 
              {-1.1347651481628418}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.6091432571411133, -0.9024731516838074}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c83" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.7763381004333496}, 
              {0.8070564270019531}}, {{-1.0242825746536255}, 
              {-0.6492380499839783}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.4026329517364502, 0.21401400864124298}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c93" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.1810808628797531}, 
              {-0.655920147895813}}, {{-0.7832494974136353}, 
              {0.34847211837768555}}}, "Real32"], "Biases" -> 
             NumericArray[{0.7287575602531433, -0.6620203852653503}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c04" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.2552524209022522}, 
              {0.06410300731658936}}, {{0.09550952166318893}, 
              {-0.07032908499240875}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.04741445183753967, -0.02364448830485344}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c14" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.0602960586547852}, 
              {-0.3740103542804718}}, {{-0.27897021174430847}, 
              {-0.02364671789109707}}}, "Real32"], "Biases" -> 
             NumericArray[{0.07600145787000656, -0.018584217876195908}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c24" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.8147105574607849}, 
              {0.44923898577690125}}, {{-0.28097033500671387}, 
              {0.2038925439119339}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.6316654086112976, 0.048634156584739685}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c34" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.6718764305114746}, 
              {0.0001493577437940985}}, {{1.398755669593811}, 
              {0.001728274393826723}}}, "Real32"], "Biases" -> 
             NumericArray[{0.5671581029891968, 0.3193013370037079}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c44" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.83546382188797}, 
              {0.4711421728134155}}, {{0.7362845540046692}, 
              {1.360549807548523}}}, "Real32"], "Biases" -> 
             NumericArray[{1.071379542350769, -0.10544069111347198}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c54" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{2.1328790187835693}, 
              {-0.017147956416010857}}, {{-0.00028199527878314257}, 
              {-0.005496859550476074}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.6049219369888306, 0.00040052886470220983}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c64" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.40771085023880005}, 
              {-0.1616455763578415}}, {{-0.21932204067707062}, 
              {-0.1405484825372696}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.016134070232510567, 0.012168784625828266}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c74" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.8231390118598938}, 
              {2.090355396270752}}, {{-1.429673671722412}, 
              {-1.131338119506836}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.9201170206069946, 0.12384921312332153}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c84" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.6224364042282104}, 
              {0.003418371779844165}}, {{-0.7477829456329346}, 
              {0.010717947967350483}}}, "Real32"], "Biases" -> 
             NumericArray[{0.4283660650253296, 0.3011798858642578}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c94" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.9553853869438171}, 
              {-0.5906440615653992}}, {{0.5812298059463501}, 
              {-0.6035030484199524}}}, "Real32"], "Biases" -> 
             NumericArray[{0.6755495071411133, 0.7988015413284302}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c05" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.5725042223930359}, 
              {-0.8920515179634094}}, {{-0.928952157497406}, 
              {0.5551609396934509}}}, "Real32"], "Biases" -> 
             NumericArray[{0.013811351731419563, -0.00797163788229227}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c15" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.6495943069458008}, 
              {0.2859352231025696}}, {{0.07601576298475266}, 
              {-0.3579550087451935}}}, "Real32"], "Biases" -> 
             NumericArray[{0.03193838149309158, -0.05892875790596008}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c25" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.3449994325637817}, 
              {0.0025888916570693254}}, {{2.0359272956848145}, 
              {3.4102942943573}}}, "Real32"], "Biases" -> NumericArray[
              {0.7217057943344116, -0.5016703605651855}, "Real32"]|>, 
          "Parameters" -> <|"OutputChannels" -> 2, "KernelSize" -> {1}, 
            "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, "Dilation" -> {1}, 
            "ChannelGroups" -> 1, "Dimensionality" -> 1, "Interleaving" -> 
             False, "$InputChannels" -> 2, "$InputSize" -> {1}, 
            "$OutputSize" -> {1}, "$WeightsInputChannels" -> 2|>, 
          "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c35" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.8336068391799927}, 
              {-0.6585401892662048}}, {{-0.17519038915634155}, 
              {1.2753243446350098}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.6042191386222839, -0.7162114381790161}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c45" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-0.8748956918716431}, 
              {-0.918805718421936}}, {{-0.8020936250686646}, 
              {1.5181416273117065}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.6413690447807312, -1.5099446773529053}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c55" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{2.197256326675415}, 
              {-0.00009398871043231338}}, {{-0.01164887472987175}, 
              {0.0001039889975800179}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.7503135800361633, -0.7254564762115479}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c65" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.040285561233758926}, 
              {0.005872996989637613}}, {{-0.6169944405555725}, 
              {-0.0804535299539566}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.15055623650550842, -0.749628484249115}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c75" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{2.076399326324463}, 
              {-0.7667162418365479}}, {{0.6148666143417358}, 
              {0.4279218018054962}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.8886499404907227, -0.8823449611663818}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c85" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{-1.4763506650924683}, 
              {-0.07500516623258591}}, {{-0.17777708172798157}, 
              {1.0670621395111084}}}, "Real32"], "Biases" -> 
             NumericArray[{-0.24704094231128693, -0.4645873010158539}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "c95" -> <|"Type" -> "Convolution", 
          "Arrays" -> <|"Weights" -> NumericArray[{{{0.46085965633392334}, 
              {0.5303224921226501}}, {{-0.8915169835090637}, 
              {-0.3295658230781555}}}, "Real32"], "Biases" -> 
             NumericArray[{1.1778849363327026, -0.033915214240550995}, 
              "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
            "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
            "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
            "Interleaving" -> False, "$InputChannels" -> 2, 
            "$InputSize" -> {1}, "$OutputSize" -> {1}, 
            "$WeightsInputChannels" -> 2|>, "Inputs" -> 
           <|"Input" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>|>, "output" -> <|"Type" -> "Catenate", 
          "Arrays" -> <||>, "Parameters" -> <|"Level" -> 2|>, 
          "Inputs" -> <|"Input1" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT], "Input2" -> NeuralNetworks`TensorT[
              {2, 1}, NeuralNetworks`RealT], "Input3" -> 
             NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input4" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input5" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input6" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input7" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input8" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input9" -> NeuralNetworks`TensorT[{2, 1}, NeuralNetworks`RealT], 
            "Input10" -> NeuralNetworks`TensorT[{2, 1}, 
              NeuralNetworks`RealT]|>, "Outputs" -> 
           <|"Output" -> NeuralNetworks`TensorT[{2, 10}, 
              NeuralNetworks`RealT]|>|>|>, "Edges" -> 
       {NeuralNetworks`NetPath["Nodes", "c01", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c11", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c21", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c31", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c41", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c51", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c61", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c71", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c81", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c91", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Inputs", "Input"], 
        NeuralNetworks`NetPath["Nodes", "c02", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c01", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c12", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c11", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c22", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c21", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c32", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c31", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c42", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c41", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c52", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c51", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c62", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c61", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c72", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c71", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c82", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c81", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c92", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c91", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c03", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c02", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c13", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c12", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c23", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c22", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c33", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c32", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c43", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c42", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c53", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c52", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c63", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c62", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c73", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c72", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c83", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c82", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c93", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c92", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c04", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c03", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c14", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c13", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c24", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c23", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c34", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c33", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c44", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c43", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c54", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c53", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c64", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c63", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c74", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c73", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c84", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c83", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c94", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c93", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c05", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c04", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c15", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c14", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c25", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c24", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c35", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c34", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c45", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c44", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c55", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c54", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c65", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c64", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c75", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c74", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c85", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c84", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "c95", "Inputs", "Input"] -> 
         NeuralNetworks`NetPath["Nodes", "c94", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input1"] -> 
         NeuralNetworks`NetPath["Nodes", "c05", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input2"] -> 
         NeuralNetworks`NetPath["Nodes", "c15", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input3"] -> 
         NeuralNetworks`NetPath["Nodes", "c25", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input4"] -> 
         NeuralNetworks`NetPath["Nodes", "c35", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input5"] -> 
         NeuralNetworks`NetPath["Nodes", "c45", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input6"] -> 
         NeuralNetworks`NetPath["Nodes", "c55", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input7"] -> 
         NeuralNetworks`NetPath["Nodes", "c65", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input8"] -> 
         NeuralNetworks`NetPath["Nodes", "c75", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input9"] -> 
         NeuralNetworks`NetPath["Nodes", "c85", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Nodes", "output", "Inputs", "Input10"] -> 
         NeuralNetworks`NetPath["Nodes", "c95", "Outputs", "Output"], 
        NeuralNetworks`NetPath["Outputs", "Output"] -> NeuralNetworks`NetPath[
          "Nodes", "output", "Outputs", "Output"]}|>, 
    "2" -> <|"Type" -> "Pooling", "Arrays" -> <||>, 
      "Parameters" -> <|"KernelSize" -> {2}, "Stride" -> {1}, 
        "PaddingSize" -> {{0, 0}}, "Function" -> Max, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$Channels" -> 2, "$InputSize" -> {10}, 
        "$OutputSize" -> {9}, "$MXPoolingConvention" -> "valid", 
        "$MXGlobalPool" -> False, "$IgnorePadding" -> False, 
        "$InputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT], 
        "$OutputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT]|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 10}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "3" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.5940709114074707}, 
          {0.6439008712768555}}, {{1.587494134902954}, 
          {-0.6475618481636047}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.5272935628890991, -0.5798681378364563}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "4" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.17491459846496582}, 
          {-0.5375261902809143}}, {{-0.9908528923988342}, 
          {-0.47787460684776306}}}, "Real32"], "Biases" -> 
         NumericArray[{0.3532203435897827, 0.4000185430049896}, "Real32"]|>, 
      "Parameters" -> <|"OutputChannels" -> 2, "KernelSize" -> {1}, 
        "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, "Dilation" -> {1}, 
        "ChannelGroups" -> 1, "Dimensionality" -> 1, "Interleaving" -> False, 
        "$InputChannels" -> 2, "$InputSize" -> {9}, "$OutputSize" -> {9}, 
        "$WeightsInputChannels" -> 2|>, "Inputs" -> 
       <|"Input" -> NeuralNetworks`TensorT[{2, 9}, NeuralNetworks`RealT]|>, 
      "Outputs" -> <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "5" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.24260011315345764}, 
          {0.7946774959564209}}, {{-0.012858958914875984}, 
          {0.004041438922286034}}}, "Real32"], "Biases" -> 
         NumericArray[{0.3416846990585327, 0.01581326313316822}, "Real32"]|>, 
      "Parameters" -> <|"OutputChannels" -> 2, "KernelSize" -> {1}, 
        "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, "Dilation" -> {1}, 
        "ChannelGroups" -> 1, "Dimensionality" -> 1, "Interleaving" -> False, 
        "$InputChannels" -> 2, "$InputSize" -> {9}, "$OutputSize" -> {9}, 
        "$WeightsInputChannels" -> 2|>, "Inputs" -> 
       <|"Input" -> NeuralNetworks`TensorT[{2, 9}, NeuralNetworks`RealT]|>, 
      "Outputs" -> <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "6" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{-0.0005985390744172037}, 
          {0.7727560997009277}}, {{-1.3644527196884155}, 
          {0.000014000392184243537}}}, "Real32"], "Biases" -> 
         NumericArray[{0.0009564366773702204, -0.3145161271095276}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "7" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.00046461320016533136}, 
          {0.8342608213424683}}, {{-0.016138121485710144}, 
          {-0.002643238753080368}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.26455599069595337, 0.026185577735304832}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "8" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.8316607475280762}, 
          {-0.0006680211517959833}}, {{0.0011866497807204723}, 
          {-0.05551080405712128}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.23260824382305145, 0.0014294235734269023}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "9" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.6456488370895386}, 
          {0.0010894042206928134}}, {{-0.0011248876107856631}, 
          {0.06108600273728371}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.19655123353004456, 0.0026600526180118322}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "10" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{1.3299678564071655}, 
          {-0.07709292322397232}}, {{-0.3175572454929352}, 
          {-0.2176697701215744}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.2122552990913391, 0.15557414293289185}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "11" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.40712711215019226}, 
          {-0.1384543776512146}}, {{0.5056553483009338}, 
          {-0.18415920436382294}}}, "Real32"], "Biases" -> 
         NumericArray[{-0.24465185403823853, -0.24200724065303802}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "12" -> <|"Type" -> "Convolution", 
      "Arrays" -> <|"Weights" -> NumericArray[{{{0.6174838542938232}, 
          {-0.49380120635032654}}, {{0.8417347073554993}, 
          {0.9074159264564514}}}, "Real32"], "Biases" -> 
         NumericArray[{0.02254711277782917, -0.2787156403064728}, 
          "Real32"]|>, "Parameters" -> <|"OutputChannels" -> 2, 
        "KernelSize" -> {1}, "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, 
        "Dilation" -> {1}, "ChannelGroups" -> 1, "Dimensionality" -> 1, 
        "Interleaving" -> False, "$InputChannels" -> 2, "$InputSize" -> {9}, 
        "$OutputSize" -> {9}, "$WeightsInputChannels" -> 2|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>|>, "13" -> <|"Type" -> "Pooling", 
      "Arrays" -> <||>, "Parameters" -> <|"KernelSize" -> {2}, 
        "Stride" -> {1}, "PaddingSize" -> {{0, 0}}, "Function" -> Max, 
        "Dimensionality" -> 1, "Interleaving" -> False, "$Channels" -> 2, 
        "$InputSize" -> {9}, "$OutputSize" -> {8}, "$MXPoolingConvention" -> 
         "valid", "$MXGlobalPool" -> False, "$IgnorePadding" -> False, 
        "$InputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT], 
        "$OutputType" -> NeuralNetworks`TensorT[{}, NeuralNetworks`RealT]|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 9}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2, 8}, 
          NeuralNetworks`RealT]|>|>, "14" -> <|"Type" -> "Flatten", 
      "Arrays" -> <||>, "Parameters" -> <|"Level" -> Infinity|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2, 8}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{16}, NeuralNetworks`RealT]|>|>, 
    "15" -> <|"Type" -> "Linear", "Arrays" -> 
       <|"Weights" -> NumericArray[{{0.11065726727247238, 
          -0.23241271078586578, 0.08644770830869675, 0.030376218259334564, 
          -0.11666859686374664, 0.1373983472585678, -0.09981124103069305, 
          0.07536797225475311, 0.10641425848007202, -0.7515684962272644, 
          0.4892755150794983, 0.6241282224655151, 0.49766695499420166, 
          -0.07832186669111252, 0.7117944359779358, 0.0834769681096077}, 
          {-0.4339424967765808, 0.4794886112213135, -0.029896585270762444, 
          0.08369274437427521, 0.25204265117645264, -0.10009995102882385, 
          -0.1252923160791397, 0.02331526391208172, 0.2108374536037445, 
          -0.36106839776039124, 0.017967747524380684, -0.062302812933921814, 
          0.07071805000305176, -0.1458667516708374, 0.03472144156694412, 
          0.026149624958634377}, {0.23280203342437744, 0.0901898741722107, 
          0.055381108075380325, -0.02759956195950508, 0.1886797845363617, 
          0.14060038328170776, -0.18355347216129303, -0.05015785992145538, 
          0.01379531342536211, -0.13113467395305634, -0.0003999283944722265, 
          0.03887814283370972, -0.03759559243917465, 0.0805310532450676, 
          -0.05620808154344559, 0.04988382011651993}, {0.24826999008655548, 
          0.09529682248830795, -0.4228877127170563, -0.05058246850967407, 
          -0.03298800066113472, -0.03274145722389221, 0.05399569869041443, 
          0.1402541548013687, 0.2649875581264496, -0.26452532410621643, 
          0.04849247634410858, -0.043291833251714706, 0.02967170812189579, 
          -0.11273686587810516, -0.006798754911869764, 0.049227308481931686}, 
          {-0.2491355836391449, -0.13012650609016418, -0.07321875542402267, 
          0.1256018429994583, -0.026442917063832283, -0.17014114558696747, 
          -0.011162498034536839, -0.11353598535060883, 
          -0.0009180514025501907, -0.016184711828827858, 0.06894141435623169, 
          0.024333134293556213, -0.013826270587742329, -0.006958879064768553, 
          -0.02070186659693718, 0.0239277184009552}, {-0.14219112694263458, 
          0.1688375324010849, -0.059997037053108215, 0.23043681681156158, 
          -0.2879299521446228, -0.184468612074852, 0.06560615450143814, 
          0.1686883121728897, -0.27116042375564575, 0.36789411306381226, 
          -0.0802449882030487, 0.060409415513277054, -0.038543738424777985, 
          0.17528395354747772, 0.0259847454726696, -0.11941348761320114}}, 
          "Real32"], "Biases" -> NumericArray[{-0.3387117385864258, 
          -0.2665066719055176, 0.1922813504934311, -0.3830546736717224, 
          -0.09581351280212402, 0.6614318490028381}, "Real32"]|>, 
      "Parameters" -> <|"OutputDimensions" -> {6}, "$OutputSize" -> 6, 
        "$InputSize" -> 16, "$InputDimensions" -> {16}|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{16}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{6}, NeuralNetworks`RealT]|>|>, 
    "16" -> <|"Type" -> "Linear", "Arrays" -> 
       <|"Weights" -> NumericArray[{{-0.0007501807413063943, 
          -0.034293822944164276, -0.013690550811588764, 0.008188596926629543, 
          -0.0157434344291687, 0.022838100790977478}, {0.42712220549583435, 
          -0.007192050106823444, 0.004183575976639986, -0.008229958824813366, 
          0.010354728437960148, 0.004924331326037645}, 
          {0.0004368712252471596, -0.005537660792469978, 
          0.010160790756344795, -0.038816481828689575, -0.02709936909377575, 
          -0.00871281884610653}, {0.0023042112588882446, 
          0.00013257346290629357, 0.03533903509378433, -0.04134146124124527, 
          0.0014406254049390554, 0.027703503146767616}}, "Real32"], 
        "Biases" -> NumericArray[{0.0008004205883480608, -0.5066829919815063, 
          -0.0006680915830656886, 0.004768035840243101}, "Real32"]|>, 
      "Parameters" -> <|"OutputDimensions" -> {4}, "$OutputSize" -> 4, 
        "$InputSize" -> 6, "$InputDimensions" -> {6}|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{6}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{4}, NeuralNetworks`RealT]|>|>, 
    "17" -> <|"Type" -> "Linear", "Arrays" -> 
       <|"Weights" -> NumericArray[{{-7.101793016772717*^-6, 
          -0.6053329110145569, -0.0009103452321141958, 
          -0.004789688158780336}, {0.0004829414829146117, 
          -0.0009788393508642912, -0.02740192972123623, 
          0.004516907501965761}}, "Real32"], "Biases" -> 
         NumericArray[{0.601650595664978, 0.005071660503745079}, "Real32"]|>, 
      "Parameters" -> <|"OutputDimensions" -> {2}, "$OutputSize" -> 2, 
        "$InputSize" -> 4, "$InputDimensions" -> {4}|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{4}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2}, NeuralNetworks`RealT]|>|>, 
    "18" -> <|"Type" -> "Linear", "Arrays" -> 
       <|"Weights" -> NumericArray[{{0.9927254319190979, 
          0.042175766080617905}, {0.2560926675796509, 0.04494502767920494}}, 
          "Real32"], "Biases" -> NumericArray[{0.8156651854515076, 
          -0.8156726956367493}, "Real32"]|>, "Parameters" -> 
       <|"OutputDimensions" -> {2}, "$OutputSize" -> 2, "$InputSize" -> 2, 
        "$InputDimensions" -> {2}|>, "Inputs" -> 
       <|"Input" -> NeuralNetworks`TensorT[{2}, NeuralNetworks`RealT]|>, 
      "Outputs" -> <|"Output" -> NeuralNetworks`TensorT[{2}, 
          NeuralNetworks`RealT]|>|>, "19" -> <|"Type" -> "Softmax", 
      "Arrays" -> <||>, "Parameters" -> <|"Level" -> -1|>, 
      "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{2}, 
          NeuralNetworks`RealT]|>, "Outputs" -> 
       <|"Output" -> NeuralNetworks`TensorT[{2}, NeuralNetworks`RealT]|>|>|>, 
  "Edges" -> {NeuralNetworks`NetPath["Nodes", "1", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Inputs", "Input"], 
    NeuralNetworks`NetPath["Nodes", "2", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "1", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "3", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "2", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "4", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "3", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "5", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "4", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "6", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "5", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "7", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "6", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "8", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "7", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "9", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "8", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "10", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "9", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "11", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "10", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "12", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "11", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "13", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "12", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "14", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "13", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "15", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "14", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "16", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "15", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "17", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "16", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "18", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "17", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Nodes", "19", "Inputs", "Input"] -> 
     NeuralNetworks`NetPath["Nodes", "18", "Outputs", "Output"], 
    NeuralNetworks`NetPath["Outputs", "Output"] -> NeuralNetworks`NetPath[
      "Nodes", "19", "Outputs", "Output"]}, 
  "Inputs" -> <|"Input" -> NeuralNetworks`TensorT[{1, 1}, 
      NeuralNetworks`AtomT]|>, "Outputs" -> 
   <|"Output" -> NetDecoder["Class", <|"Labels" -> {"False", "True"}, 
       "InputDepth" -> 1, "Multilabel" -> False, "Dimensions" -> 2, 
       "$Rank" -> 0, "$Version" -> "13.0.3"|>, NeuralNetworks`TensorT[{2}, 
       NeuralNetworks`RealT]]|>|>, <|"Version" -> "13.0.3", 
  "Unstable" -> False|>]
